inde<?php
header('content-type:text');
echo $_GET['echostr'];
