export default{
  //数据模板
  notice: '惊喜连连，多充多送',
  options: ['投注记录', '开奖规则', '游戏规则', '兑换礼品', '赠送好友']
}
