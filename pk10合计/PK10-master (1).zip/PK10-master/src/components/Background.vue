<template lang="pug">
    div.background
</template>
<style>
.background {
    position: absolute;
    z-index: -1;
    height: 100%;
    width: 100%;
    background: url(../assets/切图/主界面/BG.png);
    background-size: cover;
    background-repeat: no-repeat;
}
</style>
