define(function() {
    return [{
        createdAt: new Date(),
        playlaw: '单双',
        betmoney: 1000,
        multiple: 5,
        num: 3
    }, {
        createdAt: new Date(),
        playlaw: '单双',
        betmoney: 1000,
        multiple: 5,
        num: 3
    }, {
        createdAt: new Date(),
        playlaw: '单双',
        betmoney: 1000,
        multiple: 5,
        num: 3
    }, {
        createdAt: new Date(),
        playlaw: '单双',
        betmoney: 1000,
        multiple: 5,
        num: 3
    }, {
        createdAt: new Date(),
        playlaw: '单双',
        betmoney: 1000,
        multiple: 5,
        num: 3
    }, {
        createdAt: new Date(),
        playlaw: '单双',
        betmoney: 1000,
        multiple: 5,
        num: 3
    }, {
        createdAt: new Date(),
        playlaw: '单双',
        betmoney: 1000,
        multiple: 5,
        num: 3
    }]
})
