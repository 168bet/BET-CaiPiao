module.exports = [{
    "id": 31,
    "openid": null,
    "nickname": null,
    "headimgurl": null,
    "money": 2000.0,
    "createdAt": 1472846583000,
    "username": "liushao121",
    "password": "12333333",
    "tel": "12345678901",
    "isagent": 3,
    "rebate": 0.3
}]