module.exports = {
    // 用户信息数据模板
    'createdAt': 1469548675000,
    'money': -1,
    'code': 0,
    'nickname': '测试用户222',
    'openid': 'xxxxxxxxxxxx'
}