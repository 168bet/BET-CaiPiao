module.exports = [{
    "id": 1,
    "gName": "猜字游戏",
    "type": "大小单双",
    "rate": 10,
    "moneyLimit": 10000,
    "initMoney": 1000
}]