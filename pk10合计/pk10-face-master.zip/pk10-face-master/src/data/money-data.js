define(function() {
    return [{
        goodname: '10000金币',
        price: '100',
        goodsimg: require('../assets/切图/商城/金币.png'),
        goodsnum: 200
    }, {
        goodname: '50000金币',
        price: '100',
        goodsimg: require('../assets/切图/商城/金币.png'),
        goodsnum: 200
    }, {
        goodname: '10W金币',
        price: '100',
        goodsimg: require('../assets/切图/商城/金币.png'),
        goodsnum: 200
    }, {
        goodname: '50W金币',
        price: '100',
        goodsimg: require('../assets/切图/商城/金币.png'),
        goodsnum: 200
    }]
})
