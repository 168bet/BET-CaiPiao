export default {
    //数据模板
    notice: {
        'content': '?????',
        'createdAt': 1469543980000,
        'id': 6,
        'title': 'title'
    },
    options: ['投注记录', '游戏规则', '兑换礼品', '赠送好友', '切换账户']
}
