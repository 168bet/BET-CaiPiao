define(function (openid) {
    // 用户押注的数据模板
    return {
        id: '',
        type: '',
        betmoney: -1,
        betimg: require('./../assets/切图/主界面/5X筹码-拷贝.png'),
        mulit: '',
        betnum: '',
        createdAt: '',
        userinfoOpenid: openid
    }
})