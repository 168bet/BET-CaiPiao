#新手引导页面SplanshAct
固定几秒进行跳转
#主页HomeAct
#4个Fragment