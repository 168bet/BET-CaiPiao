package com.laowopcdandan28.entity;

/**
 * Created by Administrator on 2017/5/18 0018.
 */

public class Pk10_omit {

    public RootBean root;

    public static class RootBean {
        public WeuBean weu;
        public GuanyaheBean guanyahe;
        public static class WeuBean {
            public LaHmBean one;
            public LaHmBean two;
            public LaHmBean three;
            public LaHmBean four;
            public LaHmBean five;
            public LaHmBean six;
            public LaHmBean seven;
            public LaHmBean eight;
            public LaHmBean night;
            public LaHmBean ten;


        }
        public static class GuanyaheBean {
            public  HaoMaBean haoma;
        }
    }
}
