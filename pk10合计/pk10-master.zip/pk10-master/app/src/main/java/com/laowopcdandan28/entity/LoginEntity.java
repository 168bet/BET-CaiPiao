package com.laowopcdandan28.entity;


public class LoginEntity {
    public String gid;
    public String username;
    @Override
    public String toString() {
        return "ResDataBean{" +
                "gid='" + gid + '\'' +
                ", username='" + username + '\'' +
                '}';
    }
}
