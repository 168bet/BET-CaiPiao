package com.laowopcdandan28.bean;

import com.laowopcdandan28.http.JRParser;

import org.xutils.http.annotation.HttpResponse;

/**
 * Created by Administrator on 2017/5/16 0016.
 */
@HttpResponse(parser = JRParser.class)

public class Pk10Bean extends BaseBean{
}
