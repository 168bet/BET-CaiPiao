package com.laowopcdandan28.entity;

/**
 * Created by Administrator on 2017/5/18 0018.
 */

public class LaHmBean {
    public HaoMaBean haoma;

    @Override
    public String toString() {
        return "LaHmBean{" +
                "haoma=" + haoma +
                '}';
    }
}
