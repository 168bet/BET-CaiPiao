package com.laowopcdandan28.entity;

import java.util.List;

/**
 * Created by Administrator on 2017/5/18 0018.
 */

public class HaoMaBean {
    public List<NumberBean> number;

    @Override
    public String toString() {
        return "HaoMaBean{" +
                "number=" + number +
                '}';
    }
}
