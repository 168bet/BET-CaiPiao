package com.laowopcdandan28.impl;

/**
 * Created by tony on 2016/2/16.
 */
public interface OnOperationListener {
     void onLeftClick();

     void onRightClick();
}
