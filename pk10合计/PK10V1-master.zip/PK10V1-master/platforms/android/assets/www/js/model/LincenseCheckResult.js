/**
 * Created by Felix on 2016/4/27.
 */
var LicenseCheckResult = function(isValid, expirationDate){
    this.isValid = isValid;
    this.exirationDate = expirationDate;
}