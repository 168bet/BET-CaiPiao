﻿var AwardResult = function (periodNumber, awardTime, awardNumbers) {
    this.periodNumber = periodNumber;
    this.awardTime = awardTime;
    this.awardNumbers = awardNumbers;
}