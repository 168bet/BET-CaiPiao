/**
 * Created by Felix on 2016/4/21.
 */
var TimeSpan = function(days, hours, minutes, seconds){
    this.days = days;
    this.hours = hours;
    this.minutes = minutes;
    this.seconds = seconds;
}