package com.pk10.util;

/**
 * Created by dengfengdecao on 16/9/9.
 */
public class Const {
    public static final String ERROR_MSG = "errorMsg";
    public static final String SUCCESS_MSG = "successMsg";

    public static final String SERVER_URL = "https://eco.taobao.com/router/rest";
    public static final String APP_KEY = "23459304";
    public static final String APP_SECRET = "0b047673de18bd17e21231c024637fb6";
    public static final String SMS_TEMPLATE_CODE = "SMS_15000356";
    public static final String SMS_TYPE = "normal";
    public static final String SMS_FREE_SIGN_NAME = "数字互娱";
}
