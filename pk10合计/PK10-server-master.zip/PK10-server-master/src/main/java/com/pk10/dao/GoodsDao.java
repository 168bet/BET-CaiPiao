package com.pk10.dao;

import com.pk10.bean.Goods;

public interface GoodsDao extends BaseDao<Goods>{

}
