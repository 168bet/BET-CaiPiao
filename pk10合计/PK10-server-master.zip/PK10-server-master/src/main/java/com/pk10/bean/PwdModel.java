package com.pk10.bean;

/**
 * Created by ron on 16-9-27.
 */
public class PwdModel {
    private String newPwd;
    private String oldPwd;

    public String getNewPwd() {
        return newPwd;
    }

    public void setNewPwd(String newPwd) {
        this.newPwd = newPwd;
    }

    public String getOldPwd() {
        return oldPwd;
    }

    public void setOldPwd(String oldPwd) {
        this.oldPwd = oldPwd;
    }
}
