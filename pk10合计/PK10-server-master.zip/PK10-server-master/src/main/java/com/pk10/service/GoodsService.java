package com.pk10.service;

import com.pk10.bean.Goods;

public interface GoodsService extends BaseService<Goods>{
}
