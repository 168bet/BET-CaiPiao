package com.pk10.util;

/**
 * 微信支付签名算法
 * 
 * @author Administrator
 *
 */
public class WeChatPaySign {
	
}
