/*
-- Query: SELECT * FROM pk10.userinfo
LIMIT 0, 1000

-- Date: 2016-09-05 01:28
*/
INSERT INTO `userinfo` (`id`,`openid`,`nickname`,`money`,`createdAt`,`tel`,`username`,`password`,`isagent`,`rebate`,`owner`) VALUES (31,NULL,NULL,20000000,'2016-09-03 04:03:03','12345678901','liushao121','12333333',3,4444,0);
INSERT INTO `userinfo` (`id`,`openid`,`nickname`,`money`,`createdAt`,`tel`,`username`,`password`,`isagent`,`rebate`,`owner`) VALUES (36,NULL,NULL,0,NULL,'1233333','liushao','123456',2,NULL,0);
INSERT INTO `userinfo` (`id`,`openid`,`nickname`,`money`,`createdAt`,`tel`,`username`,`password`,`isagent`,`rebate`,`owner`) VALUES (37,NULL,NULL,0,NULL,'1233333','0.0738474819305166','123456',0,NULL,36);
INSERT INTO `userinfo` (`id`,`openid`,`nickname`,`money`,`createdAt`,`tel`,`username`,`password`,`isagent`,`rebate`,`owner`) VALUES (38,NULL,NULL,0,NULL,'1233333','0.7099869803896717','123456',0,NULL,36);
INSERT INTO `userinfo` (`id`,`openid`,`nickname`,`money`,`createdAt`,`tel`,`username`,`password`,`isagent`,`rebate`,`owner`) VALUES (39,NULL,NULL,0,NULL,'1233333','0.36864265963982645','123456',0,NULL,36);
INSERT INTO `userinfo` (`id`,`openid`,`nickname`,`money`,`createdAt`,`tel`,`username`,`password`,`isagent`,`rebate`,`owner`) VALUES (40,NULL,NULL,0,NULL,'1233333','0.6814165259248846','123456',0,NULL,36);
INSERT INTO `userinfo` (`id`,`openid`,`nickname`,`money`,`createdAt`,`tel`,`username`,`password`,`isagent`,`rebate`,`owner`) VALUES (41,NULL,NULL,0,NULL,'1233333','0.6665783777734059','123456',0,NULL,36);
INSERT INTO `userinfo` (`id`,`openid`,`nickname`,`money`,`createdAt`,`tel`,`username`,`password`,`isagent`,`rebate`,`owner`) VALUES (42,NULL,NULL,0,NULL,'1233333','0.2637473020060339','123456',0,NULL,36);
INSERT INTO `userinfo` (`id`,`openid`,`nickname`,`money`,`createdAt`,`tel`,`username`,`password`,`isagent`,`rebate`,`owner`) VALUES (43,NULL,NULL,0,NULL,'1233333','0.299621221395742','123456',0,NULL,36);
INSERT INTO `userinfo` (`id`,`openid`,`nickname`,`money`,`createdAt`,`tel`,`username`,`password`,`isagent`,`rebate`,`owner`) VALUES (44,NULL,NULL,0,NULL,'1233333','0.048255548608832854','123456',0,NULL,36);
INSERT INTO `userinfo` (`id`,`openid`,`nickname`,`money`,`createdAt`,`tel`,`username`,`password`,`isagent`,`rebate`,`owner`) VALUES (45,NULL,NULL,0,NULL,'1233333','0.37704974699247795','123456',0,NULL,36);
INSERT INTO `userinfo` (`id`,`openid`,`nickname`,`money`,`createdAt`,`tel`,`username`,`password`,`isagent`,`rebate`,`owner`) VALUES (46,NULL,NULL,0,NULL,'1233333','0.3979074887853865','123456',0,NULL,36);
INSERT INTO `userinfo` (`id`,`openid`,`nickname`,`money`,`createdAt`,`tel`,`username`,`password`,`isagent`,`rebate`,`owner`) VALUES (47,NULL,NULL,0,NULL,'1233333','0.44838362544590904','123456',0,NULL,36);
INSERT INTO `userinfo` (`id`,`openid`,`nickname`,`money`,`createdAt`,`tel`,`username`,`password`,`isagent`,`rebate`,`owner`) VALUES (48,NULL,NULL,0,NULL,'1233333','0.6982134251473445','123456',0,NULL,36);
INSERT INTO `userinfo` (`id`,`openid`,`nickname`,`money`,`createdAt`,`tel`,`username`,`password`,`isagent`,`rebate`,`owner`) VALUES (49,NULL,NULL,0,NULL,'1233333','0.2466202111751521','123456',0,NULL,36);
INSERT INTO `userinfo` (`id`,`openid`,`nickname`,`money`,`createdAt`,`tel`,`username`,`password`,`isagent`,`rebate`,`owner`) VALUES (50,NULL,NULL,0,NULL,'1233333','0.8467922061619494','123456',0,NULL,36);
INSERT INTO `userinfo` (`id`,`openid`,`nickname`,`money`,`createdAt`,`tel`,`username`,`password`,`isagent`,`rebate`,`owner`) VALUES (51,NULL,NULL,0,NULL,'1233333','0.5630098171633677','123456',0,NULL,36);
INSERT INTO `userinfo` (`id`,`openid`,`nickname`,`money`,`createdAt`,`tel`,`username`,`password`,`isagent`,`rebate`,`owner`) VALUES (52,NULL,NULL,0,NULL,'1233333','0.011378905809784179','123456',0,NULL,36);
INSERT INTO `userinfo` (`id`,`openid`,`nickname`,`money`,`createdAt`,`tel`,`username`,`password`,`isagent`,`rebate`,`owner`) VALUES (53,NULL,NULL,0,NULL,'1233333','0.9916609451925331','123456',0,NULL,36);
INSERT INTO `userinfo` (`id`,`openid`,`nickname`,`money`,`createdAt`,`tel`,`username`,`password`,`isagent`,`rebate`,`owner`) VALUES (54,NULL,NULL,0,NULL,'1233333','0.704399168677977','123456',0,NULL,36);
INSERT INTO `userinfo` (`id`,`openid`,`nickname`,`money`,`createdAt`,`tel`,`username`,`password`,`isagent`,`rebate`,`owner`) VALUES (55,NULL,NULL,0,NULL,'1233333','0.29336508457559163','123456',0,NULL,36);
INSERT INTO `userinfo` (`id`,`openid`,`nickname`,`money`,`createdAt`,`tel`,`username`,`password`,`isagent`,`rebate`,`owner`) VALUES (56,NULL,NULL,0,NULL,'1233333','0.7956173064940457','123456',0,NULL,36);
INSERT INTO `userinfo` (`id`,`openid`,`nickname`,`money`,`createdAt`,`tel`,`username`,`password`,`isagent`,`rebate`,`owner`) VALUES (57,NULL,NULL,0,NULL,'1233333','liushao121','12333333',0,NULL,36);

select * from pk10.userinfo;

delete from pk10.userinfo where id  = 57;

update pk10.userinfo set money = 10000000 where id = 31;

select * from userbet;