﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;

namespace newball
{
    class hashtable
    {
        internal static Hashtable hash1;
        internal static Hashtable hash2;//<PrivateImplementationDetails>.$$method0x6000942-1
        internal static Hashtable hash3;//<PrivateImplementationDetails>.$$method0x6000942-2
        internal static Hashtable hash4;
        internal static Hashtable hash5;
        internal static Hashtable hash6;
        internal static Hashtable hash7;
        internal static Hashtable hash8;
        internal static Hashtable hash9;
        internal static Hashtable hash0;
    }
}
