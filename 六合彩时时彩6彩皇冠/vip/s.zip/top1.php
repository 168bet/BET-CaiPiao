<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	background-color: #494949;
}
body,td,th {
	font-size: 12px;
	color: #494949;
}
a:link {
	text-decoration: none;
	color: #494949;
}
a:visited {
	text-decoration: none;
	color: #494949;
}
a:hover {
	text-decoration: underline;
	color: #494949;
}
a:active {
	text-decoration: none;
}
-->
</style>
<SCRIPT language=JAVASCRIPT>
if(self == top) {location = '/';}
if(window.location.host!=top.location.host){top.location=window.location;}


function rl_rl1(bb){
rl1.style.color="666666"
rl2.style.color="666666"
rl3.style.color="666666"
rl4.style.color="666666"
rl5.style.color="666666"

rl6.style.color="494949"
rl7.style.color="494949"
rl8.style.color="494949"
rl9.style.color="494949"
rl10.style.color="494949"
rl11.style.color="494949"
rl12.style.color="494949"
rl13.style.color="494949"
rl15.style.color="494949"
rl14.style.color="494949"
rl16.style.color="494949"
rl17.style.color="494949"
rl19.style.color="666666"
rl18.style.color="494949"
rl20.style.color="666666"
rl21.style.color="666666"
rl22.style.color="666666"
rl23.style.color="666666"



bb.style.color="ff0000"
}

</SCRIPT>
<body scroll="no" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="164" height="74" valign="top"><img src="images/top_01.gif" width="164" height="74"></td>
    <td background="images/top_02.gif"><table width="100%" height="77" border="0" cellpadding="0" cellspacing="0">
      <tr>
        <td height="44" valign="middle" nowrap><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="17" height="30" align="center">&nbsp;</td>
            <td width="777" nowrap><font color=666666><a href="#"  onClick="rl_rl1(rl1);javascript:parent.parent.mem_order.location.href='index.php?action=h';"><SPAN id=rl1 STYLE='color:666666;'>����ע��</span></a> �� <a href="#" onClick="rl_rl1(rl2);javascript:parent.parent.mem_order.location.href='index.php?action=l';"><SPAN id=rl2 STYLE='color:666666;'>�˻���ʷ</span></a> �� <a href="#"  onClick="rl_rl1(rl3);javascript:parent.parent.mem_order.location.href='index.php?action=edit';"><SPAN id=rl3 STYLE='color:666666;'>��Ա����</span></a> �� <a href="#"  onClick="rl_rl1(rl4);javascript:parent.parent.mem_order.location.href='index.php?action=sm';"><SPAN id=rl4 STYLE='color:666666;'>����˵��</span></a> �� <a href="#"  onClick="rl_rl1(rl19);javascript:parent.parent.mem_order.location.href='index.php?action=xt_kk';"><SPAN id=rl19 STYLE='color:666666;'>��������</span></a> �� <a href="#"  onClick="rl_rl1(rl20);javascript:parent.parent.mem_order.location.href='index.php?action=stop';"><SPAN id=rl20 STYLE='color:666666;'>��ʱ����</span></a> �� <a href="#"  onClick="rl_rl1(rl5);javascript:parent.parent.mem_order.location.href='index.php?action=kakithe';"><SPAN id=rl5 STYLE='color:666666;'>�������</span></a> ��<a href="index.php?action=logout" target="_top"><font color="666666">�˳�</font></a></font></td>
            <td width="11" nowrap>&nbsp;</td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td nowrap><table width="760" border="0" cellpadding="1" cellspacing="2">
          <tr>
            <td width="8" align="center"></td>
            <td align="center"><a href="#" onClick="rl_rl1(rl6);javascript:parent.parent.mem_order.location.href='index.php?action=k_tm';"><SPAN id=rl6 STYLE='color:ff0000;'>����</SPAN></a></td>
            <td width="2" align="center"><font color=494949>��</font></td>
            <td align="center"><a href="#" onClick="rl_rl1(rl7);javascript:parent.parent.mem_order.location.href='index.php?action=k_bb';"><SPAN id=rl7 STYLE='color:494949;'>�벨</SPAN></a></td>
            <td width="2" align="center"><font color=494949>��</font></td>
            <td align="center"><a href="#" onClick="rl_rl1(rl8);javascript:parent.parent.mem_order.location.href='index.php?action=k_ws';"><SPAN id=rl8 STYLE='color:494949;'>β��</SPAN></a></td>
			<td width="2" align="center"><font color=494949>��</font></td>
            <td align="center"><a href="#" onClick="rl_rl1(rl23);javascript:parent.parent.mem_order.location.href='index.php?action=k_sx';"><SPAN id=rl23 STYLE='color:494949;'>��Ф</SPAN></a></td>
           
            <td width="2" align="center"><font color=494949>��</font></td>
            <td align="center"><a href="#" onClick="rl_rl1(rl10);javascript:parent.parent.mem_order.location.href='index.php?action=k_wx';"><SPAN id=rl10 STYLE='color:494949;'>����</SPAN></a></td>
            <td width="2" align="center"><font color=494949>��</font></td>
            <td align="center"><a href="#" onClick="rl_rl1(rl11);javascript:parent.parent.mem_order.location.href='index.php?action=k_sxp';"><SPAN id=rl11 STYLE='color:494949;'>һФ</SPAN></a></td>
            <td width="2" align="center"><font color=494949>��</font></td>
            <td align="center"><a href="#" onClick="rl_rl1(rl12);javascript:parent.parent.mem_order.location.href='index.php?action=k_sx2';"><SPAN id=rl12 STYLE='color:494949;'>��Ф</SPAN></a></td>
            <td width="2" align="center"><font color=494949>��</font></td>
            <td align="center"><a href="#" onClick="rl_rl1(rl13);javascript:parent.parent.mem_order.location.href='index.php?action=k_sx3';"><SPAN id=rl13 STYLE='color:494949;'>��Ф</SPAN></a></td>
			
			
            <td width="2" align="center"><font color=494949>��</font></td>
			
            <td align="center"><a href="#" onClick="rl_rl1(rl18);javascript:parent.parent.mem_order.location.href='index.php?action=k_sx4';"><SPAN id=rl18 STYLE='color:494949;'>��Ф</SPAN></a></td>
			 <td width="2" align="center"><font color=494949>��</font></td>
            <td align="center"><a href="#" onClick="rl_rl1(rl9);javascript:parent.parent.mem_order.location.href='index.php?action=k_sx5';"><SPAN id=rl9 STYLE='color:494949;'>��Ф</SPAN></a></td>
			
            <td width="2" align="center"><font color=494949>��</font></td>
            <td align="center"><a href="#" onClick="rl_rl1(rl14);javascript:parent.parent.mem_order.location.href='index.php?action=k_sx6';"><SPAN id=rl14 STYLE='color:494949;'>��Ф</SPAN></a></td>
			
			<td width="2" align="center"><font color=494949>��</font></td>
            <td align="center"><a href="#" onClick="rl_rl1(rl21);javascript:parent.parent.mem_order.location.href='index.php?action=k_sx5';"><SPAN id=rl21 STYLE='color:494949;'></SPAN></a></td>
			<td width="2" align="center"><font color=494949></font></td>
            <td align="center"><a href="#" onClick="rl_rl1(rl22);javascript:parent.parent.mem_order.location.href='index.php?action=k_sx6';"><SPAN id=rl22 STYLE='color:494949;'></SPAN></a></td>
            <td width="2" align="center"><font color=494949></font></td>
            <td align="center"><a href="#" onClick="rl_rl1(rl15);javascript:parent.parent.mem_order.location.href='index.php?action=k_sx4';"><SPAN id=rl15 STYLE='color:494949;'></SPAN></a></td>
            <td width="2" align="center"><font color=494949></font></td>
            <td align="center"><a href="#" onClick="rl_rl1(rl16);javascript:parent.parent.mem_order.location.href='index.php?action=k_sx5';"><SPAN id=rl16 STYLE='color:494949;'></SPAN></a></td>
            <td width="2" align="center"><font color=494949></font></td>
            <td align="center"><a href="#" onClick="rl_rl1(rl17);javascript:parent.parent.mem_order.location.href='index.php?action=k_sx6';"><SPAN id=rl17 STYLE='color:494949;'></SPAN></a></td>
            <td align="center">&nbsp;</td>
            <td align="center">&nbsp;</td>
            <td align="center">&nbsp;</td>
          </tr>
        </table></td>
      </tr>
    </table></td>
  </tr>
</table>
