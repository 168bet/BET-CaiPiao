<html><head>
<meta content="text/html; charset=gb2312" http-equiv="Content-Type"/>
<title>��������</title>
<style type="text/css">              
<!--                                               
table.bt1 {border-collpase:collapse;border:0px;}
.style1 {padding-left: 3px; padding-right: 3px; text-decoration: none; height: 32px; vertical-align: middle; padding-top: 0.5em; background-repeat: no-repeat;}
body{margin:0;}
#bottombarLT td{padding:3px;}
#bottombarD3 td{padding:10px;}
#bottombarP3 td{padding:10px;}
#LT{border:1px solid #dd0000;height:20px;line-height:20px;color:yellow;}
#P3{border:1px solid #dd0000;height:20px;line-height:20px;color:yellow;}
#D3{border:1px solid #dd0000;1px;height:20px;line-height:20px;color:yellow;}
.mic {
	PADDING-LEFT: 15px; MARGIN-BOTTOM: 2px; MARGIN-RIGHT: 45px
}
.mic td{padding: 3px;}
.style8 {color: #CCCCCC; font-weight: bold; }
a:link {
	COLOR: #000000; TEXT-DECORATION: none
}
a:visited {
	COLOR: #000000; TEXT-DECORATION: none
}
a:hover {
	COLOR: #df3081; TEXT-DECORATION: none
}
a:link {
	color: #333333;
}
#bottombarLT td {
padding:3px;
}
.g-dot {
	color: #ffffff;
	text-decoration: none;
	left: 0px;	
}
.g-dot:link {text-decoration: none;color: #ffffff}
.g-dot:visited {text-decoration: none;color: #ffffff}
.g-dot:active {text-decoration: none;color: #ffffff}
.g-dot:hover {text-decoration: none; color:#df3081;}

-->                                         
</style>
<SCRIPT language=JAVASCRIPT>
if(self == top) {location = '/';}
if(window.location.host!=top.location.host){top.location=window.location;}


function rl_rl1(bb){
rl1.style.color="ffffff"
rl2.style.color="ffffff"
rl3.style.color="ffffff"
rl4.style.color="ffffff"
rl5.style.color="ffffff"
//rl91.style.color="333333"
//rl92.style.color="333333"
//rl93.style.color="333333"

rl6.style.color="ffffff"
rl7.style.color="ffffff"
rl8.style.color="ffffff"
rl9.style.color="ffffff"
rl10.style.color="ffffff"
rl11.style.color="ffffff"
rl12.style.color="ffffff"
rl121.style.color="ffffff"
rl13.style.color="ffffff"
//rl15.style.color="ffffff"
rl14.style.color="ffffff"
//rl16.style.color="ffffff"
//rl17.style.color="ffffff"
rl19.style.color="ffffff"
rl18.style.color="ffffff"
rl20.style.color="ffffff"
rl21.style.color="ffffff"
//rl22.style.color="ffffff"
rl23.style.color="ffffff"
rl24.style.color="ffffff"
rl25.style.color="ffffff"
rl188.style.color="ffffff"
rl588.style.color="ffffff"



bb.style.color="333333"
}

</SCRIPT>
</head><body>
<?php
$result2=mysql_query("select ops,opd,opp  from ka_mem where  id=".ka_memuser("id")." order by id"); 
$row2=mysql_fetch_array($result2);
?>
<table width="100%" border="0" cellpadding="0" cellspacing="0" background="images/index_top_bg.jpg">
  <tbody><tr>                                       
    <td width="250" rowspan="3" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td width="320"><img src="images/logo.jpg" width="320" height="120"></td>
        </tr>
      </table></td>
        <td height="30" style="text-align:right; padding-right:10px; font-weight:bold">
    	<font color=#FFFFFF> 
		<a href='index.php?action=k_tm' target='k_memr'><SPAN id=rl9 style='color:#ffffff'>���ϲ�</span></a> ��
		<a href="index.php?action=h" target="k_memr"><SPAN id=rl1 STYLE='color:#ffffff;'>����ע��</span></a> �� 
		<a href="index.php?action=l" target="k_memr"><SPAN id=rl2 STYLE='color:#ffffff;'>�˻���ʷ</span></a> �� 
		<a href="index.php?action=edit" target="k_memr"><SPAN id=rl3 STYLE='color:#ffffff;'>��Ա����</span></a> �� 
		<a href="index.php?action=sm" target="k_memr"><SPAN id=rl4 STYLE='color:#ffffff;'>����˵��</span></a> �� 
		<a href="index.php?action=xt_kk" target="k_memr"><SPAN id=rl19 STYLE='color:#ffffff;'>��������</span></a> �� 
		<a href="index.php?action=stop" target="k_memr"><SPAN id=rl20 STYLE='color:#ffffff;'>��ʱ����</span></a> �� 
		<a href="index.php?action=kakithe" target="k_memr"><SPAN id=rl5 STYLE='color:#FFFFFF;'>�������</span></a> ��
		<a href="index.php?action=logout" target="_top"><img src="images/logout.jpg" border="0" /></a></font>    </td>
  </tr>
    <tr>
      <td height="40"><img src="images/btou1.gif" width="135" height="40"><img src="images/btou2.gif" width="135" height="40"><img src="images/btou3.gif" width="135" height="40"><img src="images/btou4.gif" width="135" height="40"><img src="images/btou5.gif" width="135" height="40"></td>
    </tr>
    <tr>
    <td height="30">

      <table width="650" border="0" cellpadding="1" cellspacing="2">
          <tr>
            <td width="8" align="center"></td>
            <td align="center"><a href="#" onClick="rl_rl1(rl6);javascript:parent.parent.mem_order.location.href='index.php?action=k_tm';parent.mem_order.setGZ(1);"><SPAN id=rl6 STYLE='color:000000;'>����</SPAN></a></td>
            <td align="center"><a href="#" onClick="rl_rl1(rl7);javascript:parent.parent.mem_order.location.href='index.php?action=k_zt';parent.mem_order.setGZ(2);"><SPAN id=rl7 STYLE='color:ffffff;'>����</SPAN></a></td>
            <td align="center"><a href="#" onClick="rl_rl1(rl8);javascript:parent.parent.mem_order.location.href='index.php?action=k_zm';parent.mem_order.setGZ(3);"><SPAN id=rl8 STYLE='color:ffffff;'>����</SPAN></a></td>
            <td align="center"><a href="#" onClick="rl_rl1(rl23);javascript:parent.parent.mem_order.location.href='index.php?action=k_zm6';parent.mem_order.setGZ(4);"><SPAN id=rl23 STYLE='color:ffffff;'>��1-6</SPAN></a></td>
           
            <td align="center"><a href="#" onClick="rl_rl1(rl10);javascript:parent.parent.mem_order.location.href='index.php?action=k_gg';parent.mem_order.setGZ(5);"><SPAN id=rl10 STYLE='color:ffffff;'>����</SPAN></a></td>
            <td align="center"><a href="#" onClick="rl_rl1(rl11);javascript:parent.parent.mem_order.location.href='index.php?action=k_lm';parent.mem_order.setGZ(6);"><SPAN id=rl11 STYLE='color:ffffff;'>����</SPAN></a></td>
            <td align="center"><a href="#" onClick="rl_rl1(rl12);javascript:parent.parent.mem_order.location.href='index.php?action=k_bb';parent.mem_order.setGZ(7);"><SPAN id=rl12 STYLE='color:ffffff;'>�벨</SPAN></a></td>
            <td align="center"><a href="#" onClick="rl_rl1(rl121);javascript:parent.parent.mem_order.location.href='index.php?action=k_bbb';parent.mem_order.setGZ(8);"><SPAN id=rl121 STYLE='color:ffffff;'>��벨</SPAN></a></td>
            <td align="center"><a href="#" onClick="rl_rl1(rl13);javascript:parent.parent.mem_order.location.href='index.php?action=k_ws';parent.mem_order.setGZ(9);"><SPAN id=rl13 STYLE='color:ffffff;'>����ͷβ��</SPAN></a></td>
			
            <td align="center"><a href="#" onClick="rl_rl1(rl18);javascript:parent.parent.mem_order.location.href='index.php?action=k_sxp';parent.mem_order.setGZ(10);"><SPAN id=rl18 STYLE='color:ffffff;'>һФ����β</SPAN></a></td>
            <td align="center"><a href="#" onClick="rl_rl1(rl188);javascript:parent.parent.mem_order.location.href='index.php?action=k_qsb';parent.mem_order.setGZ(11);"><SPAN id=rl188 STYLE='color:ffffff;'>��Ф��ɫ��</SPAN></a></td>
            <td align="center"><a href="#" onClick="rl_rl1(rl588);javascript:parent.parent.mem_order.location.href='index.php?action=k_wx';parent.mem_order.setGZ(12);"><SPAN id=rl588 STYLE='color:ffffff;'>����</SPAN></a></td>
			
            <td align="center" style="display:none"><a href="#" onClick="rl_rl1(rl14);javascript:parent.parent.mem_order.location.href='index.php?action=k_sx';parent.mem_order.setGZ(13);"><SPAN id=rl14 STYLE='color:ffffff;'>��Ф</SPAN></a></td>
			
            <td align="center"><a href="#" onClick="rl_rl1(rl21);javascript:parent.parent.mem_order.location.href='index.php?action=k_sx';parent.mem_order.setGZ(13);"><SPAN id=rl21 STYLE='color:ffffff;'>��&amp;��Ф</SPAN></a></td>
            <td align="center"><a href="#" onClick="rl_rl1(rl25);javascript:parent.parent.mem_order.location.href='index.php?action=k_lx2';parent.mem_order.setGZ(14);"><SPAN id=rl25 STYLE='color:ffffff;'>��Ф</SPAN></a></td>
            <td align="center"><a href="#" onClick="rl_rl1(rl24);javascript:parent.parent.mem_order.location.href='index.php?action=k_zx';parent.mem_order.setGZ(15);"><SPAN id=rl24 STYLE='color:ffffff;'>��ѡ����</SPAN></a></td>
            <!-- <td align="center"><a href="#" onClick="rl_rl1(rl22);javascript:parent.parent.mem_order.location.href='index.php?action=k_sx3';"><SPAN id=rl22 STYLE='color:ffffff;'>��Ф</SPAN></a></td>
            <td align="center"><a href="#" onClick="rl_rl1(rl15);javascript:parent.parent.mem_order.location.href='index.php?action=k_sx4';"><SPAN id=rl15 STYLE='color:ffffff;'>��Ф</SPAN></a></td>
            <td align="center"><a href="#" onClick="rl_rl1(rl16);javascript:parent.parent.mem_order.location.href='index.php?action=k_sx5';"><SPAN id=rl16 STYLE='color:ffffff;'>��Ф</SPAN></a></td>
            <td align="center"><a href="#" onClick="rl_rl1(rl17);javascript:parent.parent.mem_order.location.href='index.php?action=k_sx6';"><SPAN id=rl17 STYLE='color:ffffff;'>��Ф</SPAN></a></td> -->
          </tr>
        </table>    </td>
  </tr>
  
  <tr>
    <td height="25" colspan="2" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="33"><img src="images/scrolling01.jpg" width="33" height="25"></td>
    <td width="100%" height="26" background="images/scrolling02.jpg"><div><MARQUEE  scrollDelay=120><SPAN 
                              id=Msg><font color="#FFff00"><?=ka_config(10)?></font></SPAN>
            </MARQUEE></div></td>
    <td width="18"><img src="images/scrolling03.jpg" width="18" height="25"></td>
  </tr>
</table></td>
    </tr>
</tbody></table>
</body></html>