<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="zh-CN" lang="zh-CN">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
<title>stop</title>
</head>
<body bgcolor="#ffffff">
<div align="center">
<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0" width="400" height="80" align="middle">
<param name="allowScriptAccess" value="sameDomain" />
<param name="movie" value="images/stop.swf" /><param name="quality" value="high" /><param name="bgcolor" value="#ffffff" /><embed src="stop.swf" quality="high" bgcolor="#ffffff" width="400" height="80" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" />
</object>
</div>
</body>
</html>
