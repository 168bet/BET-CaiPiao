<?

require_once 'conjunction.php';
require_once 'config.php';

?>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
<title>�ޱ����ĵ�</title>
<style type="text/css">
<!--
body {
	background-color: #0099FF;
}
body,td,th {
	color: #FFFFFF;
	font-size: 12px;
}
-->
</style></head>

<body>
<table width="100%" height="100%" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td align="center"><?=ka_config("a10")?></td>
  </tr>
</table>
</body>
</html>
