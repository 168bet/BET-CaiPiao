function killErrors() { 
return true; 
} 
window.onerror = killErrors; 
var c,b,minrmb
c="#ffff00";
b="#ffffff";
minrmb=5;
function color_animal()
{
  
}
function red(num)
{

allps();


 if(num==1)
 {
b01.style.background=c;
b02.style.background=c;
b07.style.background=c;
b08.style.background=c;
b12.style.background=c;
b13.style.background=c;
b18.style.background=c;
b19.style.background=c;
b23.style.background=c;
b24.style.background=c;
b29.style.background=c;
b30.style.background=c;
b34.style.background=c;
b35.style.background=c;
b40.style.background=c;
b45.style.background=c;
b46.style.background=c;
 }else
 {
b01.style.background=b;
b02.style.background=b;
b07.style.background=b;
b08.style.background=b;
b12.style.background=b;
b13.style.background=b;
b18.style.background=b;
b19.style.background=b;
b23.style.background=b;
b24.style.background=b;
b29.style.background=b;
b30.style.background=b;
b34.style.background=b;
b35.style.background=b;
b40.style.background=b;
b45.style.background=b;
b46.style.background=b;
 
 }
}
function red4(num)
{
	allps();
 if(num==1)
 {

b29.style.background=c;
b30.style.background=c;
b34.style.background=c;
b35.style.background=c;
b40.style.background=c;
b45.style.background=c;
b46.style.background=c;
 }else
 {

b29.style.background=b;
b30.style.background=b;
b34.style.background=b;
b35.style.background=b;
b40.style.background=b;
b45.style.background=b;
b46.style.background=b;
 
 }
}

function red5(num)
{
	allps();
 if(num==1)
 {
b01.style.background=c;
b02.style.background=c;
b07.style.background=c;
b08.style.background=c;
b12.style.background=c;
b13.style.background=c;
b18.style.background=c;
b19.style.background=c;
b23.style.background=c;
b24.style.background=c;

 }else
 {
b01.style.background=b;
b02.style.background=b;
b07.style.background=b;
b08.style.background=b;
b12.style.background=b;
b13.style.background=b;
b18.style.background=b;
b19.style.background=b;
b23.style.background=b;
b24.style.background=b;

 
 }
}

function red6(num)
{
	allps();
 if(num==1)
 {
b01.style.background=c;
b07.style.background=c;

b12.style.background=c;
b13.style.background=c;
b19.style.background=c;
b23.style.background=c;
b29.style.background=c;
b35.style.background=c;
b45.style.background=c;
 }else
 {
b01.style.background=b;

b07.style.background=b;


b13.style.background=b;

b19.style.background=b;
b23.style.background=b;

b29.style.background=b;

b34.style.background=b;
b35.style.background=b;

b45.style.background=b;

 
 }
}
function red7(num)
{
	allps();
	
 if(num==1)
 {

b02.style.background=c;

b08.style.background=c;
b12.style.background=c;

b18.style.background=c;


b24.style.background=c;

b30.style.background=c;
b34.style.background=c;

b40.style.background=c;

b46.style.background=c;
 }else
 {

b02.style.background=b;

b08.style.background=b;
b12.style.background=b;

b18.style.background=b;

b24.style.background=b;

b30.style.background=b;
b34.style.background=b;

b40.style.background=b;

b46.style.background=b;
 
 }
}
function blue(num)
{
	allps();
if(num==1)
{
b03.style.background=c;
b04.style.background=c;
b09.style.background=c;
b10.style.background=c;
b14.style.background=c;
b15.style.background=c;
b20.style.background=c;
b25.style.background=c;
b26.style.background=c;
b31.style.background=c;
b36.style.background=c;
b37.style.background=c;
b41.style.background=c;
b42.style.background=c;
b47.style.background=c;
b48.style.background=c;
}else
{
b03.style.background=b;
b04.style.background=b;
b09.style.background=b;
b10.style.background=b;
b14.style.background=b;
b15.style.background=b;
b20.style.background=b;
b25.style.background=b;
b26.style.background=b;
b31.style.background=b;
b36.style.background=b;
b37.style.background=b;
b41.style.background=b;
b42.style.background=b;
b47.style.background=b;
b48.style.background=b;
}
}


function blue8(num)
{
	allps();
if(num==1)
{

b25.style.background=c;
b26.style.background=c;
b31.style.background=c;
b36.style.background=c;
b37.style.background=c;
b41.style.background=c;
b42.style.background=c;
b47.style.background=c;
b48.style.background=c;
}else
{

b25.style.background=b;
b26.style.background=b;
b31.style.background=b;
b36.style.background=b;
b37.style.background=b;
b41.style.background=b;
b42.style.background=b;
b47.style.background=b;
b48.style.background=b;
}
}

function blue9(num)
{
	allps();
if(num==1)
{
b03.style.background=c;
b04.style.background=c;
b09.style.background=c;
b10.style.background=c;
b14.style.background=c;
b15.style.background=c;
b20.style.background=c;

}else
{
b03.style.background=b;
b04.style.background=b;
b09.style.background=b;
b10.style.background=b;
b14.style.background=b;
b15.style.background=b;
b20.style.background=b;

}
}

function blue10(num)
{
	allps();
	
if(num==1)
{
b03.style.background=c;

b09.style.background=c;


b15.style.background=c;

b25.style.background=c;

b31.style.background=c;

b37.style.background=c;
b41.style.background=c;

b47.style.background=c;

}else
{
b03.style.background=b;

b09.style.background=b;

b15.style.background=b;

b25.style.background=b;

b31.style.background=b;

b37.style.background=b;
b41.style.background=b;

b47.style.background=b;

}
}

function blue11(num)
{
	allps();
	
if(num==1)
{

b04.style.background=c;

b10.style.background=c;
b14.style.background=c;

b20.style.background=c;

b26.style.background=c;

b36.style.background=c;

b42.style.background=c;

b48.style.background=c;
}else
{

b04.style.background=b;

b10.style.background=b;
b14.style.background=b;

b20.style.background=b;

b26.style.background=b;

b36.style.background=b;


b42.style.background=b;

b48.style.background=b;
}
}
function green(num)
{
	allps();
	
	if(num==1)
	{
b05.style.background=c;
b06.style.background=c;
b11.style.background=c;
b16.style.background=c;
b17.style.background=c;
b21.style.background=c;
b22.style.background=c;
b27.style.background=c;
b28.style.background=c;
b32.style.background=c;
b33.style.background=c;
b38.style.background=c;
b39.style.background=c;
b43.style.background=c;
b44.style.background=c;
b49.style.background=c;
}else
{
b05.style.background=b;
b06.style.background=b;
b11.style.background=b;
b16.style.background=b;
b17.style.background=b;
b21.style.background=b;
b22.style.background=b;
b27.style.background=b;
b28.style.background=b;
b32.style.background=b;
b33.style.background=b;
b38.style.background=b;
b39.style.background=b;
b43.style.background=b;
b44.style.background=b;
b49.style.background=b;
}
}

function green12(num)
{
	allps();
	
	if(num==1)
	{

b27.style.background=c;
b28.style.background=c;
b32.style.background=c;
b33.style.background=c;
b38.style.background=c;
b39.style.background=c;
b43.style.background=c;
b44.style.background=c;
b49.style.background=c;
}else
{

b27.style.background=b;
b28.style.background=b;
b32.style.background=b;
b33.style.background=b;
b38.style.background=b;
b39.style.background=b;
b43.style.background=b;
b44.style.background=b;
b49.style.background=b;
}
}

function green13(num)
{
	allps();
	if(num==1)
	{
b05.style.background=c;
b06.style.background=c;
b11.style.background=c;
b16.style.background=c;
b17.style.background=c;
b21.style.background=c;
b22.style.background=c;

}else
{
b05.style.background=b;
b06.style.background=b;
b11.style.background=b;
b16.style.background=b;
b17.style.background=b;
b21.style.background=b;
b22.style.background=b;

}
}

function green14(num)
{
	allps();
	
	if(num==1)
	{
b05.style.background=c;
b11.style.background=c;

b17.style.background=c;
b21.style.background=c;

b27.style.background=c;

b32.style.background=c;
b33.style.background=c;

b39.style.background=c;
b43.style.background=c;

b49.style.background=c;
}else
{
b05.style.background=b;

b11.style.background=b;

b17.style.background=b;
b21.style.background=b;

b27.style.background=b;

b32.style.background=b;
b33.style.background=b;

b39.style.background=b;
b43.style.background=b;

b49.style.background=b;
}
}
function green15(num)
{
	allps();
	
	if(num==1)
	{

b06.style.background=c;
b16.style.background=c;
b22.style.background=c;
b28.style.background=c;
b32.style.background=c;
b38.style.background=c;
b44.style.background=c;

}else
{

b06.style.background=b;
b16.style.background=b;
b22.style.background=b;
b28.style.background=b;
b32.style.background=b;
b38.style.background=b;
b44.style.background=b;

}
}



function single()
{ 
color_animal();
 this.myform.check.value="01,03,05,07,09,11,13,15,17,19,21,23,25,27,29,31,33,35,37,39,41,43,45,47,49";
  b01.style.background=c; 
  b02.style.background=b;
  b03.style.background=c; 
  b04.style.background=b;
  b05.style.background=c; 
  b06.style.background=b;
  b07.style.background=c; 
  b08.style.background=b;
  b09.style.background=c; 
  b10.style.background=b;
  b11.style.background=c; 
  b12.style.background=b;
  b13.style.background=c; 
  b14.style.background=b;
  b15.style.background=c; 
  b16.style.background=b;
  b17.style.background=c; 
  b18.style.background=b;
  b19.style.background=c; 
  b20.style.background=b;
  b21.style.background=c; 
  b22.style.background=b;
  b23.style.background=c; 
  b24.style.background=b;
  b25.style.background=c; 
  b26.style.background=b;
  b27.style.background=c; 
  b28.style.background=b;
  b29.style.background=c; 
  b30.style.background=b;
  b31.style.background=c; 
  b32.style.background=b;
  b33.style.background=c; 
  b34.style.background=b;
  b35.style.background=c; 
  b36.style.background=b;
  b37.style.background=c; 
  b38.style.background=b;
  b39.style.background=c; 
  b40.style.background=b;
  b41.style.background=c; 
  b42.style.background=b;
  b43.style.background=c; 
  b44.style.background=b;
  b45.style.background=c; 
  b46.style.background=b;
  b47.style.background=c; 
  b48.style.background=b;
   b49.style.background=c; 
}
function double()
{
 color_animal();
 this.myform.check.value="02,04,06,08,10,12,14,16,18,20,22,24,26,28,30,32,34,36,38,40,42,44,46,48,";
  b01.style.background=b; 
  b02.style.background=c;
  b03.style.background=b; 
  b04.style.background=c;
  b05.style.background=b; 
  b06.style.background=c;
  b07.style.background=b; 
  b08.style.background=c;
  b09.style.background=b; 
  b10.style.background=c;
  b11.style.background=b; 
  b12.style.background=c;
  b13.style.background=b; 
  b14.style.background=c;
  b15.style.background=b; 
  b16.style.background=c;
  b17.style.background=b; 
  b18.style.background=c;
  b19.style.background=b; 
  b20.style.background=c;
  b21.style.background=b; 
  b22.style.background=c;
  b23.style.background=b; 
  b24.style.background=c;
  b25.style.background=b; 
  b26.style.background=c;
  b27.style.background=b; 
  b28.style.background=c;
  b29.style.background=b; 
  b30.style.background=c;
  b31.style.background=b; 
  b32.style.background=c;
  b33.style.background=b; 
  b34.style.background=c;
  b35.style.background=b; 
  b36.style.background=c;
  b37.style.background=b; 
  b38.style.background=c;
  b39.style.background=b; 
  b40.style.background=c;
  b41.style.background=b; 
  b42.style.background=c;
  b43.style.background=b; 
  b44.style.background=c;
  b45.style.background=b; 
  b46.style.background=c;
  b47.style.background=b; 
  b48.style.background=c;
  b49.style.background=b; 
}
function mins()
{
 color_animal();
   this.myform.check.value="01,02,03,04,05,06,07,08,09,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,";
  b01.style.background=c;
  b02.style.background=c;
  b03.style.background=c;
  b04.style.background=c;
  b05.style.background=c;
  b06.style.background=c;
  b07.style.background=c;
  b08.style.background=c;
  b09.style.background=c;
  b10.style.background=c;
  b11.style.background=c;
  b12.style.background=c;
  b13.style.background=c;
  b14.style.background=c;
  b15.style.background=c;
  b16.style.background=c;
  b17.style.background=c;
  b18.style.background=c;
  b19.style.background=c;
  b20.style.background=c;
  b21.style.background=c;
  b22.style.background=c;
  b23.style.background=c;
  b24.style.background=c;
  b25.style.background=b; 
  b26.style.background=b; 
  b27.style.background=b; 
  b28.style.background=b; 
  b29.style.background=b; 
  b30.style.background=b; 
  b31.style.background=b; 
  b32.style.background=b; 
  b33.style.background=b; 
  b34.style.background=b; 
  b35.style.background=b; 
  b36.style.background=b; 
  b37.style.background=b; 
  b38.style.background=b; 
  b39.style.background=b; 
  b40.style.background=b; 
  b41.style.background=b; 
  b42.style.background=b; 
  b43.style.background=b; 
  b44.style.background=b; 
  b45.style.background=b; 
  b46.style.background=b; 
  b47.style.background=b; 
  b48.style.background=b; 
  b49.style.background=b; 
}
function mins1()
{
 color_animal();
   this.myform.check.value="01,03,05,07,09,11,13,15,17,19,21,23,";
  b01.style.background=c;
  b02.style.background=b;
  b03.style.background=c;
  b04.style.background=b;
  b05.style.background=c;
  b06.style.background=b;
  b07.style.background=c;
  b08.style.background=b;
  b09.style.background=c;
  b10.style.background=b;
  b11.style.background=c;
  b12.style.background=b;
  b13.style.background=c;
  b14.style.background=b;
  b15.style.background=c;
  b16.style.background=b;
  b17.style.background=c;
  b18.style.background=b;
  b19.style.background=c;
  b20.style.background=b;
  b21.style.background=c;
  b22.style.background=b;
  b23.style.background=c;
  b24.style.background=b;
  b25.style.background=b; 
  b26.style.background=b; 
  b27.style.background=b; 
  b28.style.background=b; 
  b29.style.background=b; 
  b30.style.background=b; 
  b31.style.background=b; 
  b32.style.background=b; 
  b33.style.background=b; 
  b34.style.background=b; 
  b35.style.background=b; 
  b36.style.background=b; 
  b37.style.background=b; 
  b38.style.background=b; 
  b39.style.background=b; 
  b40.style.background=b; 
  b41.style.background=b; 
  b42.style.background=b; 
  b43.style.background=b; 
  b44.style.background=b; 
  b45.style.background=b; 
  b46.style.background=b; 
  b47.style.background=b; 
  b48.style.background=b; 
  b49.style.background=b; 
}

function mins2()
{
 color_animal();
   this.myform.check.value="02,04,06,08,10,12,14,16,18,20,22,24,";
  b01.style.background=b;
  b02.style.background=c;
  b03.style.background=b;
  b04.style.background=c;
  b05.style.background=b;
  b06.style.background=c;
  b07.style.background=b;
  b08.style.background=c;
  b09.style.background=b;
  b10.style.background=c;
  b11.style.background=b;
  b12.style.background=c;
  b13.style.background=b;
  b14.style.background=c;
  b15.style.background=b;
  b16.style.background=c;
  b17.style.background=b;
  b18.style.background=c;
  b19.style.background=b;
  b20.style.background=c;
  b21.style.background=b;
  b22.style.background=c;
  b23.style.background=b;
  b24.style.background=c;
  b25.style.background=b; 
  b26.style.background=b; 
  b27.style.background=b; 
  b28.style.background=b; 
  b29.style.background=b; 
  b30.style.background=b; 
  b31.style.background=b; 
  b32.style.background=b; 
  b33.style.background=b; 
  b34.style.background=b; 
  b35.style.background=b; 
  b36.style.background=b; 
  b37.style.background=b; 
  b38.style.background=b; 
  b39.style.background=b; 
  b40.style.background=b; 
  b41.style.background=b; 
  b42.style.background=b; 
  b43.style.background=b; 
  b44.style.background=b; 
  b45.style.background=b; 
  b46.style.background=b; 
  b47.style.background=b; 
  b48.style.background=b; 
  b49.style.background=b; 
}

function maxs()
{ color_animal();
   this.myform.check.value="25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49";
  b01.style.background=b;
  b02.style.background=b;
  b03.style.background=b;
  b04.style.background=b;
  b05.style.background=b;
  b06.style.background=b;
  b07.style.background=b;
  b08.style.background=b;
  b09.style.background=b;
  b10.style.background=b;
  b11.style.background=b;
  b12.style.background=b;
  b13.style.background=b;
  b14.style.background=b;
  b15.style.background=b;
  b16.style.background=b;
  b17.style.background=b;
  b18.style.background=b;
  b19.style.background=b;
  b20.style.background=b;
  b21.style.background=b;
  b22.style.background=b;
  b23.style.background=b;
  b24.style.background=b;
  b25.style.background=c; 
  b26.style.background=c; 
  b27.style.background=c; 
  b28.style.background=c; 
  b29.style.background=c; 
  b30.style.background=c; 
  b31.style.background=c; 
  b32.style.background=c; 
  b33.style.background=c; 
  b34.style.background=c; 
  b35.style.background=c; 
  b36.style.background=c; 
  b37.style.background=c; 
  b38.style.background=c; 
  b39.style.background=c; 
  b40.style.background=c; 
  b41.style.background=c; 
  b42.style.background=c; 
  b43.style.background=c; 
  b44.style.background=c; 
  b45.style.background=c; 
  b46.style.background=c; 
  b47.style.background=c; 
  b48.style.background=c; 
   b49.style.background=c; 
 
}

function maxs1()
{ color_animal();
   this.myform.check.value="25,27,29,31,33,35,37,39,41,43,45,47,49";
  b01.style.background=b;
  b02.style.background=b;
  b03.style.background=b;
  b04.style.background=b;
  b05.style.background=b;
  b06.style.background=b;
  b07.style.background=b;
  b08.style.background=b;
  b09.style.background=b;
  b10.style.background=b;
  b11.style.background=b;
  b12.style.background=b;
  b13.style.background=b;
  b14.style.background=b;
  b15.style.background=b;
  b16.style.background=b;
  b17.style.background=b;
  b18.style.background=b;
  b19.style.background=b;
  b20.style.background=b;
  b21.style.background=b;
  b22.style.background=b;
  b23.style.background=b;
  b24.style.background=b;
  b25.style.background=c; 
  b26.style.background=b; 
  b27.style.background=c; 
  b28.style.background=b; 
  b29.style.background=c; 
  b30.style.background=b; 
  b31.style.background=c; 
  b32.style.background=b; 
  b33.style.background=c; 
  b34.style.background=b; 
  b35.style.background=c; 
  b36.style.background=b; 
  b37.style.background=c; 
  b38.style.background=b; 
  b39.style.background=c; 
  b40.style.background=b; 
  b41.style.background=c; 
  b42.style.background=b; 
  b43.style.background=c; 
  b44.style.background=b; 
  b45.style.background=c; 
  b46.style.background=b; 
  b47.style.background=c; 
  b48.style.background=b; 
   b49.style.background=c; 
}
function maxs2()
{ color_animal();
   this.myform.check.value="26,28,30,32,34,36,38,40,42,44,46,48,";
  b01.style.background=b;
  b02.style.background=b;
  b03.style.background=b;
  b04.style.background=b;
  b05.style.background=b;
  b06.style.background=b;
  b07.style.background=b;
  b08.style.background=b;
  b09.style.background=b;
  b10.style.background=b;
  b11.style.background=b;
  b12.style.background=b;
  b13.style.background=b;
  b14.style.background=b;
  b15.style.background=b;
  b16.style.background=b;
  b17.style.background=b;
  b18.style.background=b;
  b19.style.background=b;
  b20.style.background=b;
  b21.style.background=b;
  b22.style.background=b;
  b23.style.background=b;
  b24.style.background=b;
  b25.style.background=b; 
  b26.style.background=c; 
  b27.style.background=b; 
  b28.style.background=c; 
  b29.style.background=b; 
  b30.style.background=c; 
  b31.style.background=b; 
  b32.style.background=c; 
  b33.style.background=b; 
  b34.style.background=c; 
  b35.style.background=b; 
  b36.style.background=c; 
  b37.style.background=b; 
  b38.style.background=c; 
  b39.style.background=b; 
  b40.style.background=c; 
  b41.style.background=b; 
  b42.style.background=c; 
  b43.style.background=b; 
  b44.style.background=c; 
  b45.style.background=b; 
  b46.style.background=c; 
  b47.style.background=b; 
  b48.style.background=c; 
}

function adddouble()
{     color_animal();
       this.myform.check.value="02,04,06,08,11,13,15,17,19,20,22,24,26,28,31,33,35,37,39,40,42,44,46,48,";
       b01.style.background=b;
        b02.style.background=c;
        b03.style.background=b;
        b04.style.background=c;
        b05.style.background=b;
        b06.style.background=c;
        b07.style.background=b;
        b08.style.background=c;
        b09.style.background=b;
        b10.style.background=b;
        b11.style.background=c;
        b12.style.background=b;
        b13.style.background=c;
        b14.style.background=b;
        b15.style.background=c;
        b16.style.background=b;
        b17.style.background=c;
        b18.style.background=b;
        b19.style.background=c;
        b20.style.background=c;
        b21.style.background=b;
        b22.style.background=c;
        b23.style.background=b;
        b24.style.background=c;
        b25.style.background=b;
        b26.style.background=c;
        b27.style.background=b;
        b28.style.background=c;
        b29.style.background=b;
        b30.style.background=b;
        b31.style.background=c;
        b32.style.background=b;
        b33.style.background=c;
        b34.style.background=b;
        b35.style.background=c;
        b36.style.background=b;
        b37.style.background=c;
        b38.style.background=b;
        b39.style.background=c;
        b40.style.background=c;
        b41.style.background=b;
        b42.style.background=c;
        b43.style.background=b;
        b44.style.background=c;
        b45.style.background=b;
        b46.style.background=c;
        b47.style.background=b;
        b48.style.background=c;
       
   }
function addsingle()
{   color_animal();
  this.myform.check.value="01,03,05,07,09,10,12,14,16,18,21,23,25,27,29,30,32,34,36,38,41,43,45,47,49";
       b01.style.background=c;
        b02.style.background=b;
        b03.style.background=c;
        b04.style.background=b;
        b05.style.background=c;
        b06.style.background=b;
        b07.style.background=c;
        b08.style.background=b;
        b09.style.background=c;
        b10.style.background=c;
        b11.style.background=b;
        b12.style.background=c;
        b13.style.background=b;
        b14.style.background=c;
        b15.style.background=b;
        b16.style.background=c;
        b17.style.background=b;
        b18.style.background=c;
        b19.style.background=b;
        b20.style.background=b;
        b21.style.background=c;
        b22.style.background=b;
        b23.style.background=c;
        b24.style.background=b;
        b25.style.background=c;
        b26.style.background=b;
        b27.style.background=c;
        b28.style.background=b;
        b29.style.background=c;
        b30.style.background=c;
        b31.style.background=b;
        b32.style.background=c;
        b33.style.background=b;
        b34.style.background=c;
        b35.style.background=b;
        b36.style.background=c;
        b37.style.background=b;
        b38.style.background=c;
        b39.style.background=b;
        b40.style.background=b;
        b41.style.background=c;
        b42.style.background=b;
        b43.style.background=c;
        b44.style.background=b;
        b45.style.background=c;
        b46.style.background=b;
        b47.style.background=c;
        b48.style.background=b;
		b49.style.background=c;
   }

function fowl()
{
this.myform.check.value="03,06,07,08,09,11,15,18,19,20,21,23,27,30,31,32,33,35,39,42,43,44,45,47,";
b03.style.background=c;
b06.style.background=c;
b07.style.background=c;
b08.style.background=c;
b09.style.background=c;
b11.style.background=c;
b15.style.background=c;
b18.style.background=c;
b19.style.background=c;
b20.style.background=c;
b21.style.background=c;
b23.style.background=c;
b27.style.background=c;
b30.style.background=c;
b31.style.background=c;
b32.style.background=c;
b33.style.background=c;
b35.style.background=c;
b39.style.background=c;
b42.style.background=c;
b43.style.background=c;
b44.style.background=c;
b45.style.background=c;
b47.style.background=c;
b01.style.background=b;
b02.style.background=b;
b04.style.background=b;
b05.style.background=b;
b10.style.background=b;
b12.style.background=b;
b13.style.background=b;
b14.style.background=b;
b16.style.background=b;
b17.style.background=b;
b22.style.background=b;
b24.style.background=b;
b25.style.background=b;
b26.style.background=b;
b28.style.background=b;
b29.style.background=b;
b34.style.background=b;
b36.style.background=b;
b37.style.background=b;
b38.style.background=b;
b40.style.background=b;
b41.style.background=b;
b46.style.background=b;
b48.style.background=b;
b49.style.background=b;
}
function animal() //��
{
this.myform.check.value="01,02,04,05,10,12,13,14,16,17,22,24,25,26,28,29,34,36,37,38,40,41,46,48,49,";
b01.style.background=c;
b02.style.background=c;
b04.style.background=c;
b05.style.background=c;
b10.style.background=c;
b12.style.background=c;
b13.style.background=c;
b14.style.background=c;
b16.style.background=c;
b17.style.background=c;
b22.style.background=c;
b24.style.background=c;
b25.style.background=c;
b26.style.background=c;
b28.style.background=c;
b29.style.background=c;
b34.style.background=c;
b36.style.background=c;
b37.style.background=c;
b38.style.background=c;
b40.style.background=c;
b41.style.background=c;
b46.style.background=c;
b48.style.background=c;
b49.style.background=c;
b03.style.background=b;
b06.style.background=b;
b07.style.background=b;
b08.style.background=b;
b09.style.background=b;
b11.style.background=b;
b15.style.background=b;
b18.style.background=b;
b19.style.background=b;
b20.style.background=b;
b21.style.background=b;
b23.style.background=b;
b27.style.background=b;
b30.style.background=b;
b31.style.background=b;
b32.style.background=b;
b33.style.background=b;
b35.style.background=b;
b39.style.background=b;
b42.style.background=b;
b43.style.background=b;
b44.style.background=b;
b45.style.background=b;
b47.style.background=b;
}

function for0()
{
 this.myform.check.value="01,02,03,04,05,06,07,08,09,";
  b01.style.background=c;
  b02.style.background=c;
  b03.style.background=c;
  b04.style.background=c;
  b05.style.background=c;
  b06.style.background=c;
  b07.style.background=c;
  b08.style.background=c;
  b09.style.background=c;
  b10.style.background=b; 
  b11.style.background=b; 
  b12.style.background=b; 
  b13.style.background=b; 
  b14.style.background=b; 
  b15.style.background=b; 
  b16.style.background=b; 
  b17.style.background=b; 
  b18.style.background=b; 
  b19.style.background=b; 
  b20.style.background=b; 
  b21.style.background=b; 
  b22.style.background=b; 
  b23.style.background=b; 
  b24.style.background=b; 
  b25.style.background=b; 
  b26.style.background=b; 
  b27.style.background=b; 
  b28.style.background=b; 
  b29.style.background=b; 
  b30.style.background=b; 
  b31.style.background=b; 
  b32.style.background=b; 
  b33.style.background=b; 
  b34.style.background=b; 
  b35.style.background=b; 
  b36.style.background=b; 
  b37.style.background=b; 
  b38.style.background=b; 
  b39.style.background=b; 
  b40.style.background=b; 
  b41.style.background=b; 
  b42.style.background=b; 
  b43.style.background=b; 
  b44.style.background=b; 
  b45.style.background=b; 
  b46.style.background=b; 
  b47.style.background=b; 
  b48.style.background=b; 
  b49.style.background=b; 
}
function for1()
{
 this.myform.check.value="10,11,12,13,14,15,16,17,18,19,";
  b01.style.background=b;
  b02.style.background=b;
  b03.style.background=b;
  b04.style.background=b;
  b05.style.background=b;
  b06.style.background=b;
  b07.style.background=b;
  b08.style.background=b;
  b09.style.background=b;
  b10.style.background=c; 
  b11.style.background=c; 
  b12.style.background=c; 
  b13.style.background=c; 
  b14.style.background=c; 
  b15.style.background=c; 
  b16.style.background=c; 
  b17.style.background=c; 
  b18.style.background=c; 
  b19.style.background=c; 
  b20.style.background=b;
  b21.style.background=b;
  b22.style.background=b;
  b23.style.background=b;
  b24.style.background=b;
  b25.style.background=b;
  b26.style.background=b;
  b27.style.background=b;
  b28.style.background=b;
  b29.style.background=b;
  b30.style.background=b;
  b31.style.background=b;
  b32.style.background=b;
  b33.style.background=b;
  b34.style.background=b;
  b35.style.background=b;
  b36.style.background=b;
  b37.style.background=b;
  b38.style.background=b;
  b39.style.background=b;
  b40.style.background=b;
  b41.style.background=b;
  b42.style.background=b;
  b43.style.background=b;
  b44.style.background=b;
  b45.style.background=b;
  b46.style.background=b;
  b47.style.background=b;
  b48.style.background=b;
  b49.style.background=b;
}
function for2()
{
 this.myform.check.value="20,21,22,23,24,25,26,27,28,29,";
  b01.style.background=b;
  b02.style.background=b;
  b03.style.background=b;
  b04.style.background=b;
  b05.style.background=b;
  b06.style.background=b;
  b07.style.background=b;
  b08.style.background=b;
  b09.style.background=b;
  b10.style.background=b;
  b11.style.background=b;
  b12.style.background=b;
  b13.style.background=b;
  b14.style.background=b;
  b15.style.background=b;
  b16.style.background=b;
  b17.style.background=b;
  b18.style.background=b;
  b19.style.background=b;
  b20.style.background=c; 
  b21.style.background=c; 
  b22.style.background=c; 
  b23.style.background=c; 
  b24.style.background=c; 
  b25.style.background=c; 
  b26.style.background=c; 
  b27.style.background=c; 
  b28.style.background=c; 
  b29.style.background=c; 
  b30.style.background=b;
  b31.style.background=b;
  b32.style.background=b;
  b33.style.background=b;
  b34.style.background=b;
  b35.style.background=b;
  b36.style.background=b;
  b37.style.background=b;
  b38.style.background=b;
  b39.style.background=b;
  b40.style.background=b;
  b41.style.background=b;
  b42.style.background=b;
  b43.style.background=b;
  b44.style.background=b;
  b45.style.background=b;
  b46.style.background=b;
  b47.style.background=b;
  b48.style.background=b;
  b49.style.background=b;
}
function for3()
{
 this.myform.check.value="30,31,32,33,34,35,36,37,38,39,";
  b01.style.background=b;
  b02.style.background=b;
  b03.style.background=b;
  b04.style.background=b;
  b05.style.background=b;
  b06.style.background=b;
  b07.style.background=b;
  b08.style.background=b;
  b09.style.background=b;
  b10.style.background=b;
  b11.style.background=b;
  b12.style.background=b;
  b13.style.background=b;
  b14.style.background=b;
  b15.style.background=b;
  b16.style.background=b;
  b17.style.background=b;
  b18.style.background=b;
  b19.style.background=b;
  b20.style.background=b;
  b21.style.background=b;
  b22.style.background=b;
  b23.style.background=b;
  b24.style.background=b;
  b25.style.background=b;
  b26.style.background=b;
  b27.style.background=b;
  b28.style.background=b;
  b29.style.background=b;
  b30.style.background=c; 
  b31.style.background=c; 
  b32.style.background=c; 
  b33.style.background=c; 
  b34.style.background=c; 
  b35.style.background=c; 
  b36.style.background=c; 
  b37.style.background=c; 
  b38.style.background=c; 
  b39.style.background=c; 
  b40.style.background=b;
  b41.style.background=b;
  b42.style.background=b;
  b43.style.background=b;
  b44.style.background=b;
  b45.style.background=b;
  b46.style.background=b;
  b47.style.background=b;
  b48.style.background=b;
  b49.style.background=b;
}
function for4()
{
 this.myform.check.value="40,41,42,43,44,45,46,47,48,49,";
  b01.style.background=b;
  b02.style.background=b;
  b03.style.background=b;
  b04.style.background=b;
  b05.style.background=b;
  b06.style.background=b;
  b07.style.background=b;
  b08.style.background=b;
  b09.style.background=b;
  b10.style.background=b;
  b11.style.background=b;
  b12.style.background=b;
  b13.style.background=b;
  b14.style.background=b;
  b15.style.background=b;
  b16.style.background=b;
  b17.style.background=b;
  b18.style.background=b;
  b19.style.background=b;
  b20.style.background=b;
  b21.style.background=b;
  b22.style.background=b;
  b23.style.background=b;
  b24.style.background=b;
  b25.style.background=b;
  b26.style.background=b;
  b27.style.background=b;
  b28.style.background=b;
  b29.style.background=b;
  b30.style.background=b;
  b31.style.background=b;
  b32.style.background=b;
  b33.style.background=b;
  b34.style.background=b;
  b35.style.background=b;
  b36.style.background=b;
  b37.style.background=b;
  b38.style.background=b;
  b39.style.background=b;
  b40.style.background=c; 
  b41.style.background=c; 
  b42.style.background=c; 
  b43.style.background=c; 
  b44.style.background=c; 
  b45.style.background=c; 
  b46.style.background=c; 
  b47.style.background=c; 
  b48.style.background=c; 
  b49.style.background=c; 
}

function end0()
{
this.myform.check.value="10,20,30,40,";
b10.style.background=c;
b20.style.background=c;
b30.style.background=c;
b40.style.background=c;
b01.style.background=b;
b02.style.background=b;
b03.style.background=b;
b04.style.background=b;
b05.style.background=b;
b06.style.background=b;
b07.style.background=b;
b08.style.background=b;
b09.style.background=b;
b11.style.background=b;
b12.style.background=b;
b13.style.background=b;
b14.style.background=b;
b15.style.background=b;
b16.style.background=b;
b17.style.background=b;
b18.style.background=b;
b19.style.background=b;
b21.style.background=b;
b22.style.background=b;
b23.style.background=b;
b24.style.background=b;
b25.style.background=b;
b26.style.background=b;
b27.style.background=b;
b28.style.background=b;
b29.style.background=b;
b31.style.background=b;
b32.style.background=b;
b33.style.background=b;
b34.style.background=b;
b35.style.background=b;
b36.style.background=b;
b37.style.background=b;
b38.style.background=b;
b39.style.background=b;
b41.style.background=b;
b42.style.background=b;
b43.style.background=b;
b44.style.background=b;
b45.style.background=b;
b46.style.background=b;
b47.style.background=b;
b48.style.background=b;
b49.style.background=b;
}
function end1()
{
this.myform.check.value="01,11,21,31,41,";
b01.style.background=c;
b11.style.background=c;
b21.style.background=c;
b31.style.background=c;
b41.style.background=c;
b02.style.background=b;
b03.style.background=b;
b04.style.background=b;
b05.style.background=b;
b06.style.background=b;
b07.style.background=b;
b08.style.background=b;
b09.style.background=b;
b10.style.background=b;
b12.style.background=b;
b13.style.background=b;
b14.style.background=b;
b15.style.background=b;
b16.style.background=b;
b17.style.background=b;
b18.style.background=b;
b19.style.background=b;
b20.style.background=b;
b22.style.background=b;
b23.style.background=b;
b24.style.background=b;
b25.style.background=b;
b26.style.background=b;
b27.style.background=b;
b28.style.background=b;
b29.style.background=b;
b30.style.background=b;
b32.style.background=b;
b33.style.background=b;
b34.style.background=b;
b35.style.background=b;
b36.style.background=b;
b37.style.background=b;
b38.style.background=b;
b39.style.background=b;
b40.style.background=b;
b42.style.background=b;
b43.style.background=b;
b44.style.background=b;
b45.style.background=b;
b46.style.background=b;
b47.style.background=b;
b48.style.background=b;
b49.style.background=b;
}
function end2()
{
this.myform.check.value="02,12,22,32,42,";
b02.style.background=c;
b12.style.background=c;
b22.style.background=c;
b32.style.background=c;
b42.style.background=c;
b01.style.background=b;
b03.style.background=b;
b04.style.background=b;
b05.style.background=b;
b06.style.background=b;
b07.style.background=b;
b08.style.background=b;
b09.style.background=b;
b11.style.background=b;
b10.style.background=b;
b13.style.background=b;
b14.style.background=b;
b15.style.background=b;
b16.style.background=b;
b17.style.background=b;
b18.style.background=b;
b19.style.background=b;
b21.style.background=b;
b20.style.background=b;
b23.style.background=b;
b24.style.background=b;
b25.style.background=b;
b26.style.background=b;
b27.style.background=b;
b28.style.background=b;
b29.style.background=b;
b31.style.background=b;
b30.style.background=b;
b33.style.background=b;
b34.style.background=b;
b35.style.background=b;
b36.style.background=b;
b37.style.background=b;
b38.style.background=b;
b39.style.background=b;
b41.style.background=b;
b40.style.background=b;
b43.style.background=b;
b44.style.background=b;
b45.style.background=b;
b46.style.background=b;
b47.style.background=b;
b48.style.background=b;
b49.style.background=b;
}
function end3()
{
this.myform.check.value="03,13,23,33,43,";
b03.style.background=c;
b13.style.background=c;
b23.style.background=c;
b33.style.background=c;
b43.style.background=c;
b01.style.background=b;
b02.style.background=b;
b04.style.background=b;
b05.style.background=b;
b06.style.background=b;
b07.style.background=b;
b08.style.background=b;
b09.style.background=b;
b11.style.background=b;
b12.style.background=b;
b10.style.background=b;
b14.style.background=b;
b15.style.background=b;
b16.style.background=b;
b17.style.background=b;
b18.style.background=b;
b19.style.background=b;
b21.style.background=b;
b22.style.background=b;
b20.style.background=b;
b24.style.background=b;
b25.style.background=b;
b26.style.background=b;
b27.style.background=b;
b28.style.background=b;
b29.style.background=b;
b31.style.background=b;
b32.style.background=b;
b30.style.background=b;
b34.style.background=b;
b35.style.background=b;
b36.style.background=b;
b37.style.background=b;
b38.style.background=b;
b39.style.background=b;
b41.style.background=b;
b42.style.background=b;
b40.style.background=b;
b44.style.background=b;
b45.style.background=b;
b46.style.background=b;
b47.style.background=b;
b48.style.background=b;
b49.style.background=b;
}
function end4()
{
this.myform.check.value="04,14,24,34,44,";
b04.style.background=c;
b14.style.background=c;
b24.style.background=c;
b34.style.background=c;
b44.style.background=c;
b01.style.background=b;
b02.style.background=b;
b03.style.background=b;
b05.style.background=b;
b06.style.background=b;
b07.style.background=b;
b08.style.background=b;
b09.style.background=b;
b11.style.background=b;
b12.style.background=b;
b13.style.background=b;
b10.style.background=b;
b15.style.background=b;
b16.style.background=b;
b17.style.background=b;
b18.style.background=b;
b19.style.background=b;
b21.style.background=b;
b22.style.background=b;
b23.style.background=b;
b20.style.background=b;
b25.style.background=b;
b26.style.background=b;
b27.style.background=b;
b28.style.background=b;
b29.style.background=b;
b31.style.background=b;
b32.style.background=b;
b33.style.background=b;
b30.style.background=b;
b35.style.background=b;
b36.style.background=b;
b37.style.background=b;
b38.style.background=b;
b39.style.background=b;
b41.style.background=b;
b42.style.background=b;
b43.style.background=b;
b40.style.background=b;
b45.style.background=b;
b46.style.background=b;
b47.style.background=b;
b48.style.background=b;
b49.style.background=b;
}
function end5()
{
this.myform.check.value="05,15,25,35,45,";
b05.style.background=c;
b15.style.background=c;
b25.style.background=c;
b35.style.background=c;
b45.style.background=c;
b01.style.background=b;
b02.style.background=b;
b03.style.background=b;
b04.style.background=b;
b06.style.background=b;
b07.style.background=b;
b08.style.background=b;
b09.style.background=b;
b11.style.background=b;
b12.style.background=b;
b13.style.background=b;
b10.style.background=b;
b14.style.background=b;
b16.style.background=b;
b17.style.background=b;
b18.style.background=b;
b19.style.background=b;
b21.style.background=b;
b22.style.background=b;
b23.style.background=b;
b20.style.background=b;
b24.style.background=b;
b26.style.background=b;
b27.style.background=b;
b28.style.background=b;
b29.style.background=b;
b31.style.background=b;
b32.style.background=b;
b33.style.background=b;
b30.style.background=b;
b34.style.background=b;
b36.style.background=b;
b37.style.background=b;
b38.style.background=b;
b39.style.background=b;
b41.style.background=b;
b42.style.background=b;
b43.style.background=b;
b40.style.background=b;
b44.style.background=b;
b46.style.background=b;
b47.style.background=b;
b48.style.background=b;
b49.style.background=b;
}
function end6()
{
this.myform.check.value="06,16,26,36,46,";
b06.style.background=c;
b16.style.background=c;
b26.style.background=c;
b36.style.background=c;
b46.style.background=c;
b01.style.background=b;
b02.style.background=b;
b03.style.background=b;
b04.style.background=b;
b05.style.background=b;
b07.style.background=b;
b08.style.background=b;
b09.style.background=b;
b11.style.background=b;
b12.style.background=b;
b13.style.background=b;
b14.style.background=b;
b15.style.background=b;
b10.style.background=b;
b17.style.background=b;
b18.style.background=b;
b19.style.background=b;
b21.style.background=b;
b22.style.background=b;
b23.style.background=b;
b24.style.background=b;
b20.style.background=b;
b25.style.background=b;
b27.style.background=b;
b28.style.background=b;
b29.style.background=b;
b31.style.background=b;
b32.style.background=b;
b33.style.background=b;
b34.style.background=b;
b30.style.background=b;
b35.style.background=b;
b37.style.background=b;
b38.style.background=b;
b39.style.background=b;
b41.style.background=b;
b42.style.background=b;
b43.style.background=b;
b44.style.background=b;
b40.style.background=b;
b45.style.background=b;
b47.style.background=b;
b48.style.background=b;
b49.style.background=b;
}
function end7()
{
this.myform.check.value="07,17,27,37,47,";
b07.style.background=c;
b17.style.background=c;
b27.style.background=c;
b37.style.background=c;
b47.style.background=c;
b01.style.background=b;
b02.style.background=b;
b03.style.background=b;
b04.style.background=b;
b05.style.background=b;
b06.style.background=b;
b08.style.background=b;
b09.style.background=b;
b11.style.background=b;
b12.style.background=b;
b13.style.background=b;
b14.style.background=b;
b15.style.background=b;
b16.style.background=b;
b10.style.background=b;
b18.style.background=b;
b19.style.background=b;
b21.style.background=b;
b22.style.background=b;
b23.style.background=b;
b24.style.background=b;
b25.style.background=b;
b26.style.background=b;
b20.style.background=b;
b28.style.background=b;
b29.style.background=b;
b31.style.background=b;
b32.style.background=b;
b33.style.background=b;
b34.style.background=b;
b35.style.background=b;
b36.style.background=b;
b30.style.background=b;
b38.style.background=b;
b39.style.background=b;
b41.style.background=b;
b42.style.background=b;
b43.style.background=b;
b44.style.background=b;
b45.style.background=b;
b46.style.background=b;
b40.style.background=b;
b48.style.background=b;
b49.style.background=b;
}
function end8()
{
this.myform.check.value="08,18,28,38,48,";
b08.style.background=c;
b18.style.background=c;
b28.style.background=c;
b38.style.background=c;
b48.style.background=c;
b01.style.background=b;
b02.style.background=b;
b03.style.background=b;
b04.style.background=b;
b05.style.background=b;
b06.style.background=b;
b07.style.background=b;
b09.style.background=b;
b11.style.background=b;
b12.style.background=b;
b13.style.background=b;
b14.style.background=b;
b15.style.background=b;
b16.style.background=b;
b17.style.background=b;
b10.style.background=b;
b19.style.background=b;
b21.style.background=b;
b22.style.background=b;
b23.style.background=b;
b24.style.background=b;
b25.style.background=b;
b26.style.background=b;
b27.style.background=b;
b20.style.background=b;
b29.style.background=b;
b31.style.background=b;
b32.style.background=b;
b33.style.background=b;
b34.style.background=b;
b35.style.background=b;
b36.style.background=b;
b37.style.background=b;
b30.style.background=b;
b39.style.background=b;
b41.style.background=b;
b42.style.background=b;
b43.style.background=b;
b44.style.background=b;
b45.style.background=b;
b46.style.background=b;
b47.style.background=b;
b40.style.background=b;
b49.style.background=b;
}
function end9()
{
this.myform.check.value="09,19,29,39,49,";
b09.style.background=c;
b19.style.background=c;
b29.style.background=c;
b39.style.background=c;
b49.style.background=c;
b01.style.background=b;
b02.style.background=b;
b03.style.background=b;
b04.style.background=b;
b05.style.background=b;
b06.style.background=b;
b07.style.background=b;
b08.style.background=b;
b11.style.background=b;
b12.style.background=b;
b13.style.background=b;
b14.style.background=b;
b15.style.background=b;
b16.style.background=b;
b17.style.background=b;
b18.style.background=b;
b10.style.background=b;
b21.style.background=b;
b22.style.background=b;
b23.style.background=b;
b24.style.background=b;
b25.style.background=b;
b26.style.background=b;
b27.style.background=b;
b28.style.background=b;
b20.style.background=b;
b31.style.background=b;
b32.style.background=b;
b33.style.background=b;
b34.style.background=b;
b35.style.background=b;
b36.style.background=b;
b37.style.background=b;
b38.style.background=b;
b30.style.background=b;
b41.style.background=b;
b42.style.background=b;
b43.style.background=b;
b44.style.background=b;
b45.style.background=b;
b46.style.background=b;
b47.style.background=b;
b48.style.background=b;
b40.style.background=b;
}
function sel(arr,menu,num)
{
 nums=num+",";
 if(arr==c)
 {
menu.style.background=b;
 this.myform.check.value=(this.myform.check.value).replace(nums,"");
 }else
 {
  if(this.myform.check.value.indexOf(num)<0)
   {
   this.myform.check.value+=nums;
  menu.style.background=c;
   }
 }
}
function allps()
{
var ss=b;
b01.style.background=ss;
b02.style.background=ss;
b03.style.background=ss;
b04.style.background=ss;
b05.style.background=ss;
b06.style.background=ss;
b07.style.background=ss;
b08.style.background=ss;
b09.style.background=ss;
b10.style.background=ss;
b11.style.background=ss;
b12.style.background=ss;
b13.style.background=ss;
b14.style.background=ss;
b15.style.background=ss;
b16.style.background=ss;
b17.style.background=ss;
b18.style.background=ss;
b19.style.background=ss;
b20.style.background=ss;
b21.style.background=ss;
b22.style.background=ss;
b23.style.background=ss;
b24.style.background=ss;
b25.style.background=ss;
b26.style.background=ss;
b27.style.background=ss;
b28.style.background=ss;
b29.style.background=ss;
b30.style.background=ss;
b31.style.background=ss;
b32.style.background=ss;
b33.style.background=ss;
b34.style.background=ss;
b35.style.background=ss;
b36.style.background=ss;
b37.style.background=ss;
b38.style.background=ss;
b39.style.background=ss;
b40.style.background=ss;
b41.style.background=ss;
b42.style.background=ss;
b43.style.background=ss;
b44.style.background=ss;
b45.style.background=ss;
b46.style.background=ss;
b47.style.background=ss;
b48.style.background=ss;
b49.style.background=ss;
}
function pcolor(arr,menu,num)
{ //allps();
  
 if(arr==c)
 {
// menu.style.background=b;
 if(num==1)
 { 
  myform.sred.value="";
  red(2);
 }
 if(num==4)
 { 
  myform.sred.value="";
  red4(2);
 }
  if(num==5)
 { 
  myform.sred.value="";
  red5(2);
 }
  if(num==6)
 { 
  myform.sred.value="";
  red6(2);
 }
  if(num==7)
 { 
  myform.sred.value="";
  red7(2);
 }
 if(num==2)
 {
  myform.sred.value="";
  blue(2)
 }
 if(num==8)
 {
  myform.sred.value="";
  blue8(2)
 }
  if(num==9)
 {
  myform.sred.value="";
  blue9(2)
 }
 
  if(num==10)
 {
  myform.sred.value="";
  blue10(2)
 }
  if(num==11)
 {
  myform.sred.value="";
  blue11(2)
 }
 
 if(num==3)
 { 
  green(2);
  myform.sred.value="";
 }
 if(num==12)
 { 
  green12(2);
  myform.sred.value="";
 }
  if(num==13)
 { 
  green13(2);
  myform.sred.value="";
 }
  if(num==14)
 { 
  green14(2);
  myform.sred.value="";
 }
  if(num==15)
 { 
  green15(2);
  myform.sred.value="";
 }
 this.myform.check.value=myform.sred.value;
 }else
 {
  // menu.style.background=c;
   if(num==1)
   { 
    myform.sred.value="01,02,07,08,12,13,18,19,23,24,29,30,34,35,40,45,46,";
    red(1);
   }
    if(num==4)
   { 
    myform.sred.value="29,30,34,35,40,45,46,";
    red4(1);
   }
   
    if(num==5)
   { 
    myform.sred.value="01,02,07,08,12,13,18,19,23,24,";
    red5(1);
   }
   
    if(num==6)
   { 
    myform.sred.value="01,07,13,19,23,29,35,45,";
    red6(1);
   }
   
    if(num==7)
   { 
    myform.sred.value="02,08,12,18,24,30,34,40,46,";
    red7(1);
   }
   
   if(num==2)
   {
	myform.sred.value="03,04,09,10,14,15,20,25,26,31,36,37,41,42,47,48,";
	blue(1);
   }
   if(num==8)
   {
	myform.sred.value="25,26,31,36,37,41,42,47,48,";
	blue8(1);
   }
    if(num==9)
   {
	myform.sred.value="03,04,09,10,14,15,20,";
	blue9(1);
   }
    if(num==10)
   {
	myform.sred.value="03,09,15,25,31,37,41,47,";
	blue10(1);
   }
    if(num==11)
   {
	myform.sred.value="04,10,14,20,26,36,42,48,";
	blue11(1);
   }
   
   
   if(num==3)
   {
	myform.sred.value="05,06,11,16,17,21,22,27,28,32,33,38,39,43,44,49,";
	green(1);
   }
    if(num==12)
   {
	myform.sred.value="27,28,32,33,38,39,43,44,49,";
	green12(1);
   }
   
    if(num==13)
   {
	myform.sred.value="05,06,11,16,17,21,22,";
	green13(1);
   }
   
    if(num==14)
   {
	myform.sred.value="05,11,17,21,27,33,39,43,49,";
	green14(1);
   }
    if(num==15)
   {
	myform.sred.value="06,16,22,28,32,38,44,";
	green15(1);
   }
   
   this.myform.check.value=myform.sred.value;
 }
}

function cancel()
{
b01.style.background=b;
b02.style.background=b;
b03.style.background=b;
b04.style.background=b;
b05.style.background=b;
b06.style.background=b;
b07.style.background=b;
b08.style.background=b;
b09.style.background=b;
b10.style.background=b;
b11.style.background=b;
b12.style.background=b;
b13.style.background=b;
b14.style.background=b;
b15.style.background=b;
b16.style.background=b;
b17.style.background=b;
b18.style.background=b;
b19.style.background=b;
b20.style.background=b;
b21.style.background=b;
b22.style.background=b;
b23.style.background=b;
b24.style.background=b;
b25.style.background=b;
b26.style.background=b;
b27.style.background=b;
b28.style.background=b;
b29.style.background=b;
b30.style.background=b;
b31.style.background=b;
b32.style.background=b;
b33.style.background=b;
b34.style.background=b;
b35.style.background=b;
b36.style.background=b;
b37.style.background=b;
b38.style.background=b;
b39.style.background=b;
b40.style.background=b;
b41.style.background=b;
b42.style.background=b;
b43.style.background=b;
b44.style.background=b;
b45.style.background=b;
b46.style.background=b;
b47.style.background=b;
b48.style.background=b;
b49.style.background=b;
}
function re()
{
 var arr="yes,"+this.myform.check.value;
 var rmb=document.myform.txtrmb.value;
 if(rmb<1)
 {  alert('�������Ϊ 1 ');
 }else
 {   if(arr.indexOf("01",0)>0)
   { 
     var ads=document.myform.t01.value;
	 if(ads=="") ads=0;
     document.myform.t01.value=parseFloat(ads)+parseFloat(rmb);
    }
      if(arr.indexOf("02",0)>0)
   { 
     var ads=document.myform.t02.value;
	 if(ads=="") ads=0;
     document.myform.t02.value=parseFloat(ads)+parseFloat(rmb);
    }
      if(arr.indexOf("03",0)>0)
   { 
     var ads=document.myform.t03.value;
	 if(ads=="") ads=0;
     document.myform.t03.value=parseFloat(ads)+parseFloat(rmb);
    }
      if(arr.indexOf("04",0)>0)
   { 
     var ads=document.myform.t04.value;
	 if(ads=="") ads=0;
     document.myform.t04.value=parseFloat(ads)+parseFloat(rmb);
    }
      if(arr.indexOf("05",0)>0)
   { 
     var ads=document.myform.t05.value;
	 if(ads=="") ads=0;
     document.myform.t05.value=parseFloat(ads)+parseFloat(rmb);
    }
      if(arr.indexOf("06",0)>0)
   { 
     var ads=document.myform.t06.value;
	 if(ads=="") ads=0;
     document.myform.t06.value=parseFloat(ads)+parseFloat(rmb);
    }
      if(arr.indexOf("07",0)>0)
   { 
     var ads=document.myform.t07.value;
	 if(ads=="") ads=0;
     document.myform.t07.value=parseFloat(ads)+parseFloat(rmb);
    }
      if(arr.indexOf("08",0)>0)
   { 
     var ads=document.myform.t08.value;
	 if(ads=="") ads=0;
     document.myform.t08.value=parseFloat(ads)+parseFloat(rmb);
    }
      if(arr.indexOf("09",0)>0)
   { 
     var ads=document.myform.t09.value;
	 if(ads=="") ads=0;
     document.myform.t09.value=parseFloat(ads)+parseFloat(rmb);
    }
      if(arr.indexOf("10",0)>0)
   { 
     var ads=document.myform.t10.value;
	 if(ads=="") ads=0;
     document.myform.t10.value=parseFloat(ads)+parseFloat(rmb);
    }
      if(arr.indexOf("11",0)>0)
   { 
     var ads=document.myform.t11.value;
	 if(ads=="") ads=0;
     document.myform.t11.value=parseFloat(ads)+parseFloat(rmb);
    }
      if(arr.indexOf("12",0)>0)
   { 
     var ads=document.myform.t12.value;
	 if(ads=="") ads=0;
     document.myform.t12.value=parseFloat(ads)+parseFloat(rmb);
    }
      if(arr.indexOf("13",0)>0)
   { 
     var ads=document.myform.t13.value;
	 if(ads=="") ads=0;
     document.myform.t13.value=parseFloat(ads)+parseFloat(rmb);
    }
      if(arr.indexOf("14",0)>0)
   { 
     var ads=document.myform.t14.value;
	 if(ads=="") ads=0;
     document.myform.t14.value=parseFloat(ads)+parseFloat(rmb);
    }
      if(arr.indexOf("15",0)>0)
   { 
     var ads=document.myform.t15.value;
	 if(ads=="") ads=0;
     document.myform.t15.value=parseFloat(ads)+parseFloat(rmb);
    }
      if(arr.indexOf("16",0)>0)
   { 
     var ads=document.myform.t16.value;
	 if(ads=="") ads=0;
     document.myform.t16.value=parseFloat(ads)+parseFloat(rmb);
    }
      if(arr.indexOf("17",0)>0)
   { 
     var ads=document.myform.t17.value;
	 if(ads=="") ads=0;
     document.myform.t17.value=parseFloat(ads)+parseFloat(rmb);
    }
      if(arr.indexOf("18",0)>0)
   { 
     var ads=document.myform.t18.value;
	 if(ads=="") ads=0;
     document.myform.t18.value=parseFloat(ads)+parseFloat(rmb);
    }
      if(arr.indexOf("19",0)>0)
   { 
     var ads=document.myform.t19.value;
	 if(ads=="") ads=0;
     document.myform.t19.value=parseFloat(ads)+parseFloat(rmb);
    }
      if(arr.indexOf("20",0)>0)
   { 
     var ads=document.myform.t20.value;
	 if(ads=="") ads=0;
     document.myform.t20.value=parseFloat(ads)+parseFloat(rmb);
    }
      if(arr.indexOf("21",0)>0)
   { 
     var ads=document.myform.t21.value;
	 if(ads=="") ads=0;
     document.myform.t21.value=parseFloat(ads)+parseFloat(rmb);
    }
      if(arr.indexOf("22",0)>0)
   { 
     var ads=document.myform.t22.value;
	 if(ads=="") ads=0;
     document.myform.t22.value=parseFloat(ads)+parseFloat(rmb);
    }
      if(arr.indexOf("23",0)>0)
   { 
     var ads=document.myform.t23.value;
	 if(ads=="") ads=0;
     document.myform.t23.value=parseFloat(ads)+parseFloat(rmb);
    }
      if(arr.indexOf("24",0)>0)
   { 
     var ads=document.myform.t24.value;
	 if(ads=="") ads=0;
     document.myform.t24.value=parseFloat(ads)+parseFloat(rmb);
    }
      if(arr.indexOf("25",0)>0)
   { 
     var ads=document.myform.t25.value;
	 if(ads=="") ads=0;
     document.myform.t25.value=parseFloat(ads)+parseFloat(rmb);
    }
      if(arr.indexOf("26",0)>0)
   { 
     var ads=document.myform.t26.value;
	 if(ads=="") ads=0;
     document.myform.t26.value=parseFloat(ads)+parseFloat(rmb);
    }
      if(arr.indexOf("27",0)>0)
   { 
     var ads=document.myform.t27.value;
	 if(ads=="") ads=0;
     document.myform.t27.value=parseFloat(ads)+parseFloat(rmb);
    }
      if(arr.indexOf("28",0)>0)
   { 
     var ads=document.myform.t28.value;
	 if(ads=="") ads=0;
     document.myform.t28.value=parseFloat(ads)+parseFloat(rmb);
    }
      if(arr.indexOf("29",0)>0)
   { 
     var ads=document.myform.t29.value;
	 if(ads=="") ads=0;
     document.myform.t29.value=parseFloat(ads)+parseFloat(rmb);
    }
      if(arr.indexOf("30",0)>0)
   { 
     var ads=document.myform.t30.value;
	 if(ads=="") ads=0;
     document.myform.t30.value=parseFloat(ads)+parseFloat(rmb);
    }
      if(arr.indexOf("31",0)>0)
   { 
     var ads=document.myform.t31.value;
	 if(ads=="") ads=0;
     document.myform.t31.value=parseFloat(ads)+parseFloat(rmb);
    }
      if(arr.indexOf("32",0)>0)
   { 
     var ads=document.myform.t32.value;
	 if(ads=="") ads=0;
     document.myform.t32.value=parseFloat(ads)+parseFloat(rmb);
    }
      if(arr.indexOf("33",0)>0)
   { 
     var ads=document.myform.t33.value;
	 if(ads=="") ads=0;
     document.myform.t33.value=parseFloat(ads)+parseFloat(rmb);
    }
      if(arr.indexOf("34",0)>0)
   { 
     var ads=document.myform.t34.value;
	 if(ads=="") ads=0;
     document.myform.t34.value=parseFloat(ads)+parseFloat(rmb);
    }
      if(arr.indexOf("35",0)>0)
   { 
     var ads=document.myform.t35.value;
	 if(ads=="") ads=0;
     document.myform.t35.value=parseFloat(ads)+parseFloat(rmb);
    }
      if(arr.indexOf("36",0)>0)
   { 
     var ads=document.myform.t36.value;
	 if(ads=="") ads=0;
     document.myform.t36.value=parseFloat(ads)+parseFloat(rmb);
    }
      if(arr.indexOf("37",0)>0)
   { 
     var ads=document.myform.t37.value;
	 if(ads=="") ads=0;
     document.myform.t37.value=parseFloat(ads)+parseFloat(rmb);
    }
      if(arr.indexOf("38",0)>0)
   { 
     var ads=document.myform.t38.value;
	 if(ads=="") ads=0;
     document.myform.t38.value=parseFloat(ads)+parseFloat(rmb);
    }
      if(arr.indexOf("39",0)>0)
   { 
     var ads=document.myform.t39.value;
	 if(ads=="") ads=0;
     document.myform.t39.value=parseFloat(ads)+parseFloat(rmb);
    }
      if(arr.indexOf("40",0)>0)
   { 
     var ads=document.myform.t40.value;
	 if(ads=="") ads=0;
     document.myform.t40.value=parseFloat(ads)+parseFloat(rmb);
    }
      if(arr.indexOf("41",0)>0)
   { 
     var ads=document.myform.t41.value;
	 if(ads=="") ads=0;
     document.myform.t41.value=parseFloat(ads)+parseFloat(rmb);
    }
      if(arr.indexOf("42",0)>0)
   { 
     var ads=document.myform.t42.value;
	 if(ads=="") ads=0;
     document.myform.t42.value=parseFloat(ads)+parseFloat(rmb);
    }
      if(arr.indexOf("43",0)>0)
   { 
     var ads=document.myform.t43.value;
	 if(ads=="") ads=0;
     document.myform.t43.value=parseFloat(ads)+parseFloat(rmb);
    }
      if(arr.indexOf("44",0)>0)
   { 
     var ads=document.myform.t44.value;
	 if(ads=="") ads=0;
     document.myform.t44.value=parseFloat(ads)+parseFloat(rmb);
    }
      if(arr.indexOf("45",0)>0)
   { 
     var ads=document.myform.t45.value;
	 if(ads=="") ads=0;
     document.myform.t45.value=parseFloat(ads)+parseFloat(rmb);
    }
      if(arr.indexOf("46",0)>0)
   { 
     var ads=document.myform.t46.value;
	 if(ads=="") ads=0;
     document.myform.t46.value=parseFloat(ads)+parseFloat(rmb);
    }
      if(arr.indexOf("47",0)>0)
   { 
     var ads=document.myform.t47.value;
	 if(ads=="") ads=0;
     document.myform.t47.value=parseFloat(ads)+parseFloat(rmb);
    }
      if(arr.indexOf("48",0)>0)
   { 
     var ads=document.myform.t48.value;
	 if(ads=="") ads=0;
     document.myform.t48.value=parseFloat(ads)+parseFloat(rmb);
    }
      if(arr.indexOf("49",0)>0)
   { 
     var ads=document.myform.t49.value;
	 if(ads=="") ads=0;
     document.myform.t49.value=parseFloat(ads)+parseFloat(rmb);
    }
    }
}

function txt(ta,num)
{ 
 nums=num+",";
 if(ta.value=="")
  { 
   this.myform.check.value=(this.myform.check.value).replace(nums,"");
  }else
  {
   if(this.myform.check.value.indexOf(num)<0)
   this.myform.check.value+=nums;
  }
}
function Isnum(){
  return ((event.keyCode >= 48) && (event.keyCode <= 57));
}
function alls(arr)
{
var ss=c;
this.myform.check.value="01,02,03,04,05,06,07,08,09,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,";
b01.style.background=ss;
b02.style.background=ss;
b03.style.background=ss;
b04.style.background=ss;
b05.style.background=ss;
b06.style.background=ss;
b07.style.background=ss;
b08.style.background=ss;
b09.style.background=ss;
b10.style.background=ss;
b11.style.background=ss;
b12.style.background=ss;
b13.style.background=ss;
b14.style.background=ss;
b15.style.background=ss;
b16.style.background=ss;
b17.style.background=ss;
b18.style.background=ss;
b19.style.background=ss;
b20.style.background=ss;
b21.style.background=ss;
b22.style.background=ss;
b23.style.background=ss;
b24.style.background=ss;
b25.style.background=ss;
b26.style.background=ss;
b27.style.background=ss;
b28.style.background=ss;
b29.style.background=ss;
b30.style.background=ss;
b31.style.background=ss;
b32.style.background=ss;
b33.style.background=ss;
b34.style.background=ss;
b35.style.background=ss;
b36.style.background=ss;
b37.style.background=ss;
b38.style.background=ss;
b39.style.background=ss;
b40.style.background=ss;
b41.style.background=ss;
b42.style.background=ss;
b43.style.background=ss;
b44.style.background=ss;
b45.style.background=ss;
b46.style.background=ss;
b47.style.background=ss;
b48.style.background=ss;
b49.style.background=ss;
}



