<MARQUEE  scrollDelay=120><SPAN 
                              id=Msg><font color="#FFff00"><?=ka_config(10)?></font></SPAN>
                              </MARQUEE>