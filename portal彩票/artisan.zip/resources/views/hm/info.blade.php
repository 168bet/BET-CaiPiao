<!DOCTYPE html>
<html>
<head>
    <title>合买订单详情-趣彩网(触屏版)-专业彩票代购网站|网上投注|福彩|体彩|高频彩</title>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
    <meta charset="utf-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta content="initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0" name="viewport">
    <meta content="yes" name="apple-mobile-web-app-capable">
    <meta content="black" name="apple-mobile-web-app-status-bar-style">
    <meta content="telephone=no" name="format-detection">


    <link href="/css/main.min.css" rel="stylesheet" type="text/css"/>
    <link href="/css/common.css" rel="stylesheet" type="text/css"/>


    <script src="/scripts/share.touch.min.js" type="text/javascript"></script>
    <script src="/scripts/common.js" type="text/javascript"></script>

    <script src="/scripts/iscroll.js" type="text/javascript"></script>

    <script src="/scripts/onlinePhone.js" type="text/javascript"></script>


    <script src="/scripts/common.js" type="text/javascript"></script>

</head>
<body>
<div id="tx_c" class="logints" style="display:none;"></div>
<section id="dConfirm" class="zfPop weige_" style="position: fixed;z-index: 1000;display: none"><h4>提示</h4>
    <div class="clearfix pdLeft08 center"></div>
    <div class="zfTrue clearfix">
        <input type="button" value="取消" class="zfqx" id="zfqx"/>
        <input type="button" value="确定" id="zfqd"/>
    </div>
</section>
<div id="Mask"
     style="display: none; position: fixed; left: 0px; top: 0px; width: 100%; height: 100%; background: none repeat scroll 0% 0% gray; opacity: 0.5; z-index: 999;"></div>
<script type="text/javascript">
    //var ires = "http://res.qcwddd.com/iqucai.touch/images/";
    //var dres = "http://data.qcwddd.com/matchdata/";
</script>

<div style="position: relative;" id="outer">
    <div class="wrap">
        <link href="/css/common.css" rel="stylesheet" type="text/css"/>
        <link href="/css/hemai.css" rel="stylesheet" type="text/css"/>
        <header class="tzHeader">
            <section class="buyHeader">
                <a href="javascript:history.go(-1)" class="back">&lt;</a>
                <h1 id="pType" style="width:80%;text-align:center;">合买订单详情</h1>
            </section>
        </header>
        <section>
            <div id="hemai">
                <div class="pd063">
                    <div class="clearfix pdTop08">
                        <h2 id="gType" class="left fontSize1">竞彩混合过关</h2>
                        <cite id="expect" class="left gray pdLeft06">2017-04-17期</cite>
                    </div>
                </div>
                <div class="hmTxt">
                    <span style=" font-size:1rem; font-weight:600">发起人</span>
                    <em id="uName" class="fontSize095">足彩大富翁VIP</em>
                </div>
                <div id="ww_bdi" class="hmTxt relative clearfix" style="padding-right:0">
            <span class="left w3_6 mgTop04">
            <cite id="rg" class="per">87%</cite>
            <em id="bd" class="pro mgTop06">保 57%</em>
            </span>
                    <div class="gray left w15">
                        <p id="rgDetail">
                            总额
                            <em class="yellow">2,088元</em>
                            (保底1188元，提成10%)
                        </p>
                        <p id="surplus" class="pdTop08">
                            剩余
                            <em class="yellow">263元</em>
                            <input type="hidden" value="263" id="residue"/>
                        </p>
                    </div>
                </div>
                <div style=" background-color:#ffffff; border-bottom:1px solid #ffffff;height: 5rem;margin-top: -2rem;">
                    <div class="progress relative mgTop2 mgLeft05" style=" padding-top:2rem;">
                        <em></em>
                        <i></i>
                        <em></em>
                        <i></i>
                        <em></em>
                        <i></i>
                        <em></em>
                        <div class="clear"></div>
                        <div id="f_paint" class="progressHover_ progressHover" style="width: 6.9rem;">
                            <cite></cite>
                            <o class="barLine"></o>
                            <cite class="barCircle2"></cite>
                            <o class="barLine2"></o>
                            <cite class="barCircle3"></cite>
                            <o class="barLine3"></o>
                            <cite class="barCircle4"></cite>
                        </div>
                    </div>
                    <p class="progressTxt pdTop03">
                        <span>发起 </span><cite>出票成功</cite>
                        <o>开奖</o>
                        <i>派奖</i>
                    </p>
                </div>
                <a id="authority_1" class="hmTxt mgTop06 hmTxt2 clearfix"
                   href="../tzdetails?SchemeId=TSM0417233307331224196075" onclick=" return Checkstate()">
                    <span class="left">投注内容</span>
                    <cite class="right black">截止公开</cite>
                    <em class="hmArrow"></em>
                </a>
                <a class="hmTxt hmTxt2 clearfix" href="../hmjoin/TSM0417233307331224196075"
                   onclick=" return CheckLogin_()">
                    <span class="left">跟单用户</span>
                    <cite id="views" class="yellow right">48人</cite>
                    <em class="hmArrow"></em>
                </a>
                <a class="hmTxt hmTxt2" href="../mysubscribe?SchemeId=TSM0417233307331224196075"
                   onclick=" return CheckLogin_()">
                    我的认购
                    <em class="hmArrow"></em>
                </a>
                <a class="hmTxt hmTxt2" href="javascript:;">
                    方案编号
                    <span style=" margin-left:1rem;">TSM0417233307331224196075</span>
                </a>
                <div style=" height:0.6rem; background-color:#ffffff;"></div>
                <div id="cdesc" class="hmTxt gray mgTop06">
                    方案宣言:足彩大富翁为国内顶尖彩票高手，对国内外彩票深有研究，在足彩、竞彩、北京单场均取得不俗的战绩。足彩大富翁自有彩票研究室，由多年投身彩市，股市，期货，黄金，外汇等多个投资交易品种的资深专业人士精心组合而成，24小时不间断轮班分析和做单，请跟单的彩民朋友根据自身的状况进行理性的分散跟单，控制好跟单比例和节
                </div>

            </div>
        </section>
        <footer style="" class="buyFooter">
            <div class="fixed buyFloat">
                <span class="left pdLeft06">认购<input type="text" onkeyup="this.value=this.value.replace(/[^\d]/g,'');"
                                                     value="1" id="txt_TSM0417233307331224196075"
                                                     class="hmbuyInput">元</span>
                <input type="hidden" id="price_TSM0417233307331224196075" value="1.0000"/>
                <a id="iPay" class="ture" onclick="CheckLogin('TSM0417233307331224196075',false)"
                   href="javascript:;">购买</a>
            </div>
        </footer>
        <input type="hidden" name="name" id="stoptime" value="2017/4/19 23:54:00"/>
        <input type="hidden" name="name" id="datatime" value="2017/4/19 23:43:08"/>
        <input type="hidden" name="name" id="security" value="CompletePublic"/>
        <input type="hidden" name="name" id="schemeid" value="TSM0417233307331224196075"/>
        <input type="hidden" name="name" id="antelist" value="0"/>
        <input type="hidden" name="name" id="username" value="627593"/>
        <input type="hidden" name="name" id="toginfoname" value="182467"/>
        <script src="/scripts/hemai.js" type="text/javascript"></script>
    </div>
</div>
</body>
</html>
