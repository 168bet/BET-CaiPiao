﻿<!DOCTYPE html>
<html>
<head>
    <title>518</title>
    <meta name="keywords" content="足彩,体彩,彩票,体育彩票,足球彩票,彩票合买,高频彩票"/>
    <meta name="description"
          content="是一家服务于中国彩民手机买彩票的合买代购交易平台,我们提供专业的福利彩票,体育彩票,足球彩票,篮球彩票,高频彩票,福彩,福彩3D,并致力于为广大彩民最好的彩票平台!"/>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
    <meta charset="utf-8"/>
    <meta name="viewport" content="initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0,width=device-width"/>
    <meta name="apple-mobile-web-app-capable" content="yes"/>
    <meta name="apple-mobile-web-app-status-bar-style" content="black"/>
    <meta name="format-detection" content="telephone=no"/>
    <link href="css/main.min.css" rel="stylesheet" type="text/css"/>
    <link href="css/index.min.css" rel="stylesheet" type="text/css"/>
    <link href="css/0-0首页.css" rel="stylesheet" type="text/css"/>
    <script src="scripts/touchslide.1.1.js" type="text/javascript"></script>
    <script src="scripts/jquery-1.5.2.min.js" type="text/javascript"></script>
    <script src="scripts/default.js" type="text/javascript"></script>
    <script src="scripts/onlinephone.js" type="text/javascript"></script>

</head>
<body>
<script type="text/javascript">
    var ires = "http://res.qcwddd.com/iqucai.touch/images/";
    var dres = "http://data.qcwddd.com/matchdata/";
</script>
<div class="header">
    <div class="warp-header">
        <div class="web-title">
            518彩票
        </div>
    </div>
    <div id="focus" class="focus">
        <div class="hd">
            <ul>
            </ul>
        </div>
        <div class="bd">
            <ul>
                <a href="http://m.qcw.com/buy/jingcai" target="_blank">
                    <li _src="url(http://res.qcwddd.com/iqucai/images/add/2016111219474949.jpg)"
                        style="background:#ffffff center 0 no-repeat;">
                        <img src="picture/2016111219474949.jpg"/>
                    </li>
                </a>
                <a href="http://m.qcw.com/buy/jingcai" target="_blank">
                    <li _src="url(http://res.qcwddd.com/iqucai/images/add/2016111219482778.jpg)"
                        style="background:#ffffff center 0 no-repeat;">
                        <img src="picture/2016111219482778.jpg"/>
                    </li>
                </a>
                <a href="http://m.qcw.com/buy/cqssc" target="_blank">
                    <li _src="url(http://res.qcwddd.com/iqucai/images/add/2016111219500588.jpg)"
                        style="background:#ffffff center 0 no-repeat;">
                        <img src="picture/2016111219500588.jpg"/></li>
                </a>
                <a href="http://m.qcw.com/buy/jingcaibasket" target="_blank">
                    <li _src="url(http://res.qcwddd.com/iqucai/images/add/2016111219512056.jpg)"
                        style="background:#ffffff center 0 no-repeat;">
                        <img src="picture/2016111219512056.jpg"/></li>
                </a>
                <a href="http://m.qcw.com/staticHtml/zixun/details/20160427/ZX04272211472047955965.html"
                   target="_blank">
                    <li _src="url(http://res.qcwddd.com/iqucai/images/add/2016111219530954.jpg)"
                        style="background:#ffffff center 0 no-repeat;">
                        <img src="picture/2016111219530954.jpg"/></li>
                </a>
            </ul>
        </div>
    </div>
</div>
<div style="position: relative;" id="outer">
    <div class="wrap">
        <div class="clearfix">
        </div>
        <div class="fllist clearfix" style="display: none;">
            <a id="my_lottery2" href="javascript:;">我的彩票</a> <a href="javascript:void(0)">合买中心</a>
            <a href="javascript:void()">开奖结果</a> <a href="/jsbf/">比分直播</a>
        </div>
        <section class="float index_nav_">
            <div class="float_a">
                <div class="float_a_div" style="position: relative">
                    <a id="my_lottery" href="/member/order"><em class="icon icon1"></em>
                        <h3>我的彩票</h3></a>
                    <a href="/hemai.html"><em class="icon icon4"></em>
                        <h3>天天足球</h3></a>
                    <a href="/statichtml/lottery/index.html"><em class="icon icon3"></em>
                        <h3>开奖结果</h3></a>
                    <a href="javascript:void(0)" id="pullDown"><em class="icon icon2"></em>
                        <h3>比分直播</h3></a>

                </div>
                <div style="display: none" class="pullText addxtxg" id="pullText">
                    <a href="/statichtml/baodan/index.html">神单分享</a>
                    <a href="/app/" style="border-bottom: none">手机APP</a>
                </div>
            </div>

        </section>
        <section class="random—box">
            <div class="random—title">
                <h5 class="tl fl">2元赢千万</h5>
                <a href="" class="tr fr">换一注</a>
            </div>
            <div class="random—body">
                <div class="fl">
                    <span>01</span><span>01</span><span>01</span><span>01</span><span>01</span><span>01</span>
                    <span class="blue">01</span>
                </div>
                <div class="fr">
                    <a href="" class="buy">购买</a>
                </div>
            </div>

        </section>
        <div class="logo_list clearfix">
            <ul>
                <li><a href="/buy/ssq">
                    <i class="cz-logo ssq"></i>
                    <br>
                    <p>双色球</p> <span>2元中1千万</span></a></li>
                <li><a href="/buy/dlt">
                    <i class="cz-logo dlt"></i>
                    <br>
                    <p>大乐透</p><span>3元中1600万</span></a></li>
                <li><a href="/buy/toto"><i class="cz-logo i3d"></i>
                    <br>
                    <p>福彩3D</p><span>轻松赢千元</span></a></li>

                <li><a href="/buy/cqssc"><i class="cz-logo ssc"></i>
                    <br>
                    <p>时时彩</p><span>单注赢千万</span></a></li>
                <li><a href="/buy/jingcai"><i class="cz-logo jclq"></i>
                    <br>
                    <p>竞彩篮球</p><span>国王VS骑士</span></a></li>
                <li><a href="/buy/jingcaibasket"><i class="cz-logo i11x5"></i>
                    <br>
                    <p>11选5系列</p><span>每天都有新优惠</span></a></li>

                <li><a href="/buy/cqssc" class="b_bottom"><i class="cz-logo bj"></i>
                    <br>
                    <p>北京单场</p><span>超多比赛通宵玩</span></a></li>
                <li><a href="/buy/danchang" class="b_bottom"><i class="cz-logo jczq"></i>
                    <br>
                    <p>竞彩足球</p><span>国王VS骑士</span></a></li>
                <li><a href="/buy/jx11x5" class="b_bottom"><i class="cz-logo jzdg"></i>
                    <br>
                    <p>竞足单关</p><span>国王VS骑士</span></a></li>

                <li><a href="/buy/jx11x5" class="b_bottom"><i class="cz-logo zcx9"></i>
                    <br>
                    <p>足彩任选九</p><span>稳健14选9场</span></a></li>
                <li><a href="/buy/jx11x5" class="b_bottom"><i class="cz-logo zc14"></i>
                    <br>
                    <p>足彩十四场</p><span>2元可赚500万</span></a></li>
                <li><a href="/buy/jx11x5" class="b_bottom"><i class="cz-logo qd"></i>
                    <br>
                    <p>敬请期待</p><span>待开发</span></a></li>
            </ul>
        </div>
        <section class="inyc">
            <p class="clearfix">
                <strong>今日预测</strong>
                <a class="more fr" href="">更多&nbsp;&gt;</a>
            </p>
            <div id="yuce">
                <a href="/staticHtml/zixun/details/20170409/ZX0409150956091794421548.html"><span class="red"><em></em>【英超】埃弗顿VS莱切斯特城： 势如破竹，太妃糖主场毒杀老狐狸</span></a>
                <a href="/staticHtml/zixun/details/20170409/ZX0409145347532615565155.html"><span class="red"><em></em>【英超】桑德兰VS曼联：红魔拒绝平局誓拿三分</span></a>
                <a href="/staticHtml/zixun/details/20170408/ZX0408130512055661306812.html"><span class=""><em></em>【西甲】皇马VS马竞：冠军悬念仍在，皇马主场延续连胜记录</span></a>
                <a href="/staticHtml/zixun/details/20170408/ZX0408123708371946962998.html"><span class=""><em></em>【德甲】拜仁VS多特：大黄蜂争返三甲，拜仁为欧冠留力？</span></a>
                <a href="/staticHtml/zixun/details/20170408/ZX0408121347132041823887.html"><span class=""><em></em>【西甲】马拉加vs巴塞罗那：巴萨全队严阵以待，客场誓拿3分</span></a>
            </div>
        </section>
        <script>
            //显示隐藏帮助
            $("#pullDown").click(function () {
                if ($(".pullText").is(":visible")) {
                    $(this).removeClass("pullHover");
                    $(".pullText").hide();
                } else {
                    $(this).addClass("pullHover");
                    $(".pullText").show();
                }
            });
        </script>


    </div>
</div>
<div class="clearfix">
</div>
</body>
</html>
