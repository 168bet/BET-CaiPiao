﻿<!DOCTYPE html>
<html>
<head>
    <title>开奖结果</title>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
    <meta charset="utf-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta content="initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0" name="viewport">
    <meta content="yes" name="apple-mobile-web-app-capable">
    <meta content="black" name="apple-mobile-web-app-status-bar-style">
    <meta content="telephone=no" name="format-detection">
    <link href="/css/main.min.css" rel="stylesheet" type="text/css"/>
    <link href="/css/common.css" rel="stylesheet" type="text/css"/>
    <link href="/css/lotterytrend.css" rel="stylesheet" type="text/css"/>
    <script src="/scripts/share.touch.min.js" type="text/javascript"></script>
    <script src="/scripts/common.js" type="text/javascript"></script>
    <script src="/scripts/iscroll.js" type="text/javascript"></script>
    <script src="/scripts/onlinephone.js" type="text/javascript"></script>
</head>
<body>
<div id="tx_c" class="logints" style="display:none;"></div>
<section id="dConfirm" class="zfPop weige_" style="position: fixed;z-index: 1000;display: none"><h4>提示</h4>
    <div class="clearfix pdLeft08 center"></div>
    <div class="zfTrue clearfix">

        <input type="button" value="取消" class="zfqx" id="zfqx"/>
        <input type="button" value="确定" id="zfqd"/>
    </div>
</section>
<div id="Mask"
     style="display: none; position: fixed; left: 0px; top: 0px; width: 100%; height: 100%; background: none repeat scroll 0% 0% gray; opacity: 0.5; z-index: 999;"></div>
<script type="text/javascript">
    var ires = "http://res.qcwddd.com/iqucai.touch/images/";
    var dres = "http://data.qcwddd.com/matchdata/";
</script>

<div style="position: relative;" id="outer">
    <div class="wrap">
        <input type="hidden" value="ssq" id="gamecode"/>
        <input type="hidden" value="2017-002" id="issue"/>
        <header class="hmzxHeader">
            <section class="fixed2">
                <div class="kjHeader">
                    <h1 class="tl">
                        <a href="javascript:history.go(-1)" class="back">&lt;</a>
                        双色球&nbsp;&nbsp;&nbsp;&nbsp;开奖
                    </h1>
                </div>
            </section>
        </header>
        <div style="background: none repeat scroll 0% 0% rgb(255, 255, 255);" id="newinfo_">
            <section>
                <div id="historyList" name="historyList" class="kjall all pklist"
                     style="background: none repeat scroll 0% 0% rgb(255, 255, 255);">
                    <a href="javascript:void(0)">
                        <div class="row">
                            <div class="clearfix lskjTit">第20170314期 2017-03-14 21:15:00</div>
                            <div class="kjNum">
                                <span>15</span>
                                <span>19</span>
                                <span>23</span>
                                <span>24</span>
                                <span>25</span>
                                <span>32</span>
                                <span class='blue'>03</span>
                            </div>
                            <i class="">&or;</i>
                        </div>

                        <div class="table-box" style="display: none">
                            <table class="table">
                                <thead>
                                <tr>
                                    <th>本期销量</th>
                                    <th>累计奖池</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                    <td>13123213</td>
                                    <td>13123213</td>
                                </tr>
                                </tbody>
                            </table>
                            <table class="table">
                                <thead>
                                <tr>
                                    <th>奖项</th>
                                    <th>注数（注）</th>
                                    <th>每注金额（元）</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                    <td>13123213</td>
                                    <td>13123213</td>
                                    <td>13123213</td>
                                </tr>
                                <tr>
                                    <td>13123213</td>
                                    <td>13123213</td>
                                    <td>13123213</td>
                                </tr>
                                <tr>
                                    <td>13123213</td>
                                    <td>13123213</td>
                                    <td>13123213</td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </a>
                    <a href="javascript:void(0)">
                        <div class="row">
                            <div class="clearfix lskjTit">第20170314期 2017-03-14 21:15:00</div>
                            <div class="kjNum">
                                <span>15</span>
                                <span>19</span>
                                <span>23</span>
                                <span>24</span>
                                <span>25</span>
                                <span>32</span>
                                <span class='blue'>03</span>
                            </div>
                            <i class="">&or;</i>
                        </div>

                        <div class="table-box" style="display: none">
                            <table class="table">
                                <thead>
                                <tr>
                                    <th>本期销量</th>
                                    <th>累计奖池</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                    <td>13123213</td>
                                    <td>13123213</td>
                                </tr>
                                </tbody>
                            </table>
                            <table class="table">
                                <thead>
                                <tr>
                                    <th>奖项</th>
                                    <th>注数（注）</th>
                                    <th>每注金额（元）</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                    <td>13123213</td>
                                    <td>13123213</td>
                                    <td>13123213</td>
                                </tr>
                                <tr>
                                    <td>13123213</td>
                                    <td>13123213</td>
                                    <td>13123213</td>
                                </tr>
                                <tr>
                                    <td>13123213</td>
                                    <td>13123213</td>
                                    <td>13123213</td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </a>
                </div>
                <div class="load_more tc">加载更多</div>
            </section>
        </div>
    </div>
</div>
<script src="/scripts/trend.js" type="text/javascript"></script>
<script>
    $('.all a').click(function(){
        $(this).find('.table-box').toggle();
    })
</script>
</body>
</html>
