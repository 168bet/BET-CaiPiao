﻿<!DOCTYPE html>
<html>
<head>
    <title>时时彩</title>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
    <meta charset="utf-8"/>
    <meta name="_token" content="{{ csrf_token() }}"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta content="initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0" name="viewport">
    <meta content="yes" name="apple-mobile-web-app-capable">
    <meta content="black" name="apple-mobile-web-app-status-bar-style">
    <meta content="telephone=no" name="format-detection">
    <link href="/css/main.min.css" rel="stylesheet" type="text/css"/>
    <link href="/css/common.css" rel="stylesheet" type="text/css"/>
    <link href="/css/cqssc.css" rel="stylesheet" type="text/css" media="screen"/>
    <script src="/scripts/share.touch.min.js" type="text/javascript"></script>
    <script src="/scripts/common.js" type="text/javascript"></script>
    <script src="/scripts/iscroll.js" type="text/javascript"></script>
    <script src="/scripts/onlinephone.js" type="text/javascript"></script>
</head>
<body>
<div id="tx_c" class="logints" style="display:none;"></div>
<section id="dConfirm" class="zfPop weige_" style="position: fixed;z-index: 1000;display: none"><h4>提示</h4>
    <div class="clearfix pdLeft08 center"></div>
    <div class="zfTrue clearfix">
        <input type="button" value="取消" class="zfqx" id="zfqx"/>
        <input type="button" value="确定" id="zfqd"/>
    </div>
</section>
<div id="Mask"
     style="display: none; position: fixed; left: 0px; top: 0px; width: 100%; height: 100%; background: none repeat scroll 0% 0% gray; opacity: 0.5; z-index: 999;"></div>
<script type="text/javascript">
    var ires = "http://res.qcwddd.com/iqucai.touch/images/";
    var dres = "http://data.qcwddd.com/matchdata/";
</script>
<div style="position: relative;" id="outer">
    <div class="wrap">
        <section>
            <article id="content_home" style="display: block;">
                <header class="tzHeader">
                    <section class="fcHeader">
                        <a href="javascript:history.go(-1)" class="back">&lt;</a>
                        <h1>时时彩</h1>
                        <div class="pullDown">
                            <em class="fcpullIco" id="pullIco"></em>
                            <div style="display:none" class="pullText" id="pullText">
                                <a href="/hemai.html">合买跟单</a>
                                <a href="/statichtml/lottery/index.html">开奖结果</a>
                                <a href="/statichtml/lottery/index.html">玩法帮助</a>
                            </div>
                        </div>
                    </section>
                </header>
                <section id="wraper">
                    <div>
                        <nav class="clearfix" id="cqssc_tab">
                            <div style="overflow:hidden;width:100%" class="jxsscTab sdTab" id="secNav">
                                <ul style="list-style: outside none none; display: block; float: left; width: 1180px; height: 100%; padding: 0px; transition-property: transform; transform-origin: 0px 0px 0px; transform: translate(0px, 0px) scale(1) translateZ(0px);" id="play_tabs">
                                    <li val="DXDS" class="cur" v="DXDS">大小单双</li>
                                    <li val="1XDX" class="" v="1XDX">一星直选</li>
                                    <li val="2XDX" class="" v="2XDX">二星直选</li>
                                    <li val="3XDX" class="" v="3XDX">三星直选</li>
                                    <li val="5XDX" class="" v="5XDX">五星直选</li>
                                    <li val="5XTX" class="" v="5XTX">五星通选</li>
                                    <li val="2XZXFS" class="" v="2XZXFS">二星组选</li>
                                    <li val="ZX3FS" class="" v="ZX3FS">三星组三</li>
                                    <li val="ZX6" class="" v="ZX6">三星组六</li>
                                    <li val="2XHZ" class="" v="2XHZ">二星合值</li>
                                </ul>
                            </div>
                        </nav>
                        <article>
                            <div id="c_c" class="k3kj clearfix">
                                <div id="kj_" class="k3kjtext">
                                    <p>55期开奖 大小单双</p>
                                    <div class="jxsscball pdTop03 clearfix">
										<div class="history fl">
											<span>0</span>
											<span>1</span>
											<span>2</span>
											<span class="red">1</span>
											<span class="red">2</span>
										</div>
                                        <em class="kjup kjdown fl" id="kjup"></em>
                                    </div>
                                </div>
                                <div id="jxssc" class="k3kjnum">
                                    <p>距<em id="c_expect">056</em>期截止</p>
                                    <strong>00:07</strong>
                                </div>
                            </div>
                            <div id="kj_code" style=" display:none">
                                <ul class="k3listtt">
                                    <li class="wb20">期号</li>
                                    <li class="jxsscwb18">开奖结果</li>
                                    <li class="wb21">十位</li>
                                    <li class="wb21">个位</li>
                                    <li class="wb21">后三</li>
                                </ul>
                                <div class="cqssckjlist k3kjlist">
                                    <ul><li class="wb20">025期</li><li class="jxsscdice jxsscwb18"><b>1</b><b>2</b><b>5</b><b>8</b><b>2</b></li><li class="wb21">大双</li><li class="wb21">小双</li><li class="wb19">组六</li></ul>
                                    <ul><li class="wb20">025期</li><li class="jxsscdice jxsscwb18"><b>1</b><b>2</b><b>5</b><b>8</b><b>2</b></li><li class="wb21">大双</li><li class="wb21">小双</li><li class="wb19">组六</li></ul>
                                    <ul><li class="wb20">025期</li><li class="jxsscdice jxsscwb18"><b>1</b><b>2</b><b>5</b><b>8</b><b>2</b></li><li class="wb21">大双</li><li class="wb21">小双</li><li class="wb19">组六</li></ul>
                                </div>
                            </div>
                        </article>
                        <article>
                            <div class="relative k3xh" id="bonus_">
                                <div style="display: block;">猜中十位、个位属性,奖金<em class="yellow">4</em>元</div>
                                <div style="display: none;">猜中个位号码，奖金<em class="yellow">10</em>元</div>
                                <div style="display: none;">按顺序猜中十位、个位，奖金<em class="yellow">100</em>元</div>
                                <div style="display: none;">按顺序猜中百位、十位、个位，奖金<em class="yellow">1000</em>元</div>
                                <div style="display: none;">按顺序猜中全部，奖金<em class="yellow">100000</em>元</div>
                                <div style="display: none;" class="jxssctitle">
                                    <p>按顺序猜中5位，奖金<em class="yellow">20440</em>元</p>
                                    <p>按顺序猜中前3位或后3，奖金<em class="yellow">200</em>元</p>
                                    <p>按顺序猜中前2位或后2，奖金<em class="yellow">20</em>元</p>
                                </div>
                                <div style="display: none;">选2个号，猜中后2位组合（顺序不限），奖金<em class="yellow">50</em>元</div>
                                <div style="display: none;" class="jxssctitle">
                                    <p>选2个号，猜中后3位组三号码，奖金<em class="yellow">320</em>元</p>
                                    <p>组三：3号码中有2个相同，如323</p>
                                </div>
                                <div style="display: none;" class="jxssctitle">
                                    <p>选3个号，猜中后3位组六号码，奖金<em class="yellow">160</em>元</p>
                                    <p>组六：3号码各不相同，如321</p>
                                </div>
                                <div style="display: none;" class="jxssctitle">
                                    <p>猜中十位、各位之和，奖金<em class="yellow">50</em>元</p>
                                    <p>（若开奖号后两位相同，奖金<em class="yellow">100</em>元）</p>
                                </div>
                                <div class="shakeOmit" id="shake">
                                    <em class="shakeico"></em>
                                    <cite class="red" style="padding:.75rem 0 0 .05rem;display:inline-block">摇一注</cite>
                                </div>
                            </div>
                            <!-- 大小单双start -->
                            <div class="jxsscxhlist jxsscdxds" style="display: block;" id="DXDS">
                                <ul class="clearfix hide">
                                    <li m="y" v="十位" class="cur"><span>十位</span></li>
                                    <li m="y" v="个位" class="cur"><span>个位</span></li>
                                </ul>
                                <div class="jxsscxhBall mgTop03 clearfix">
                                    <div v="DXDS" idx=0>
                                        <p><b v="2">大</b><b v="1" class="">小</b></p>
                                        <p><b v="5">单</b><b v="4" class="">双</b></p>
                                    </div>
                                    <div v="DXDS" idx=1>
                                        <p><b v="2">大</b><b v="1" class="">小</b></p>
                                        <p><b v="5">单</b><b v="4" class="">双</b></p>
                                    </div>
                                </div>
                            </div>
                            <!-- 大小单双end -->
                            <!-- 一星直选start -->
                            <div class="jxsscxhlist" id="1XDX" style="display: none;">
                                <ul class="clearfix hide">
                                    <li><span>万位</span></li>
                                    <li><span>千位</span></li>
                                    <li><span>百位</span></li>
                                    <li><span>十位</span></li>
                                    <li m="y" v="个位" class="cur"><span>个位</span></li>
                                </ul>
                                <div class="jxsscxhBall mgTop03 clearfix" v="1XDX" idx=4>
                                    <span>个位</span>
                                    <p><b>0</b><b>1</b><b>2</b><b>3</b><b>4</b><b>5</b><b>6</b><b>7</b><b>8</b><b>9</b>
                                    </p>
                                </div>
                            </div>
                            <!-- 一星直选end -->
                            <!-- 二星直选start -->
                            <div class="jxsscxhlist" style="display: none;" id="2XDX">
                                <ul class="clearfix hide">
                                    <li><span>万位</span></li>
                                    <li><span>千位</span></li>
                                    <li><span>百位</span></li>
                                    <li m="y" v="十位" class="cur"><span>十位</span></li>
                                    <li m="y" v="个位" class="cur"><span>个位</span></li>
                                </ul>
                                <div class="jxsscxhBall mgTop03 jxsscline clearfix" v="2XDX" idx=3>
                                    <span>十位</span>
                                    <p><b>0</b><b>1</b><b>2</b><b>3</b><b>4</b><b>5</b><b>6</b><b>7</b><b>8</b><b>9</b>
                                    </p>
                                </div>
                                <div class="jxsscxhBall mgTop03 clearfix" v="2XDX" idx=4>
                                    <span>个位</span>
                                    <p><b>0</b><b>1</b><b>2</b><b>3</b><b>4</b><b>5</b><b>6</b><b>7</b><b>8</b><b>9</b>
                                    </p>
                                </div>
                            </div>
                            <!-- 二星直选end -->
                            <!-- 三星直选start -->
                            <div class="jxsscxhlist" style="display: none;" id="3XDX">
                                <ul class="clearfix hide">
                                    <li><span>万位</span></li>
                                    <li><span>千位</span></li>
                                    <li m="y" v="百位" class="cur"><span>百位</span></li>
                                    <li m="y" v="十位" class="cur"><span>十位</span></li>
                                    <li m="y" v="个位" class="cur"><span>个位</span></li>
                                </ul>
                                <div class="jxsscxhBall mgTop03 jxsscline clearfix" v="3XDX" idx=2>
                                    <span>百位</span>
                                    <p><b>0</b><b>1</b><b>2</b><b>3</b><b>4</b><b>5</b><b>6</b><b>7</b><b>8</b><b>9</b>
                                    </p>
                                </div>
                                <div class="jxsscxhBall mgTop03 jxsscline clearfix" v="3XDX" idx=3>
                                    <span>十位</span>
                                    <p><b>0</b><b>1</b><b>2</b><b>3</b><b>4</b><b>5</b><b>6</b><b>7</b><b>8</b><b>9</b>
                                    </p>
                                </div>
                                <div class="jxsscxhBall mgTop03 clearfix" v="3XDX" idx=4>
                                    <span>个位</span>
                                    <p><b>0</b><b>1</b><b>2</b><b>3</b><b>4</b><b>5</b><b>6</b><b>7</b><b>8</b><b>9</b>
                                    </p>
                                </div>
                            </div>
                            <!-- 三星直选end -->
                            <!-- 五星直选start -->
                            <div class="jxsscxhlist" style="display: none;" id="5XDX">
                                <ul class="clearfix hide">
                                    <li m="y" v="万位" class="cur"><span>万位</span></li>
                                    <li m="y" v="千位" class="cur"><span>千位</span></li>
                                    <li m="y" v="百位" class="cur"><span>百位</span></li>
                                    <li m="y" v="十位" class="cur"><span>十位</span></li>
                                    <li m="y" v="个位" class="cur"><span>个位</span></li>
                                </ul>
                                <div class="jxsscxhBall mgTop03 jxsscline clearfix" v="5XDX" idx=0>
                                    <span>万位</span>
                                    <p><b>0</b><b>1</b><b>2</b><b>3</b><b>4</b><b>5</b><b>6</b><b>7</b><b>8</b><b>9</b>
                                    </p>
                                </div>
                                <div class="jxsscxhBall mgTop03 jxsscline clearfix" v="5XDX" idx=1>
                                    <span>千位</span>
                                    <p><b>0</b><b>1</b><b>2</b><b>3</b><b>4</b><b>5</b><b>6</b><b>7</b><b>8</b><b>9</b>
                                    </p>
                                </div>
                                <div class="jxsscxhBall mgTop03 jxsscline clearfix" v="5XDX" idx=2>
                                    <span>百位</span>
                                    <p><b>0</b><b>1</b><b>2</b><b>3</b><b>4</b><b>5</b><b>6</b><b>7</b><b>8</b><b>9</b>
                                    </p>
                                </div>
                                <div class="jxsscxhBall mgTop03 jxsscline clearfix" v="5XDX" idx=3>
                                    <span>十位</span>
                                    <p><b>0</b><b>1</b><b>2</b><b>3</b><b>4</b><b>5</b><b>6</b><b>7</b><b>8</b><b>9</b>
                                    </p>
                                </div>
                                <div class="jxsscxhBall mgTop03 clearfix" v="5XDX" idx=4>
                                    <span>个位</span>
                                    <p><b>0</b><b>1</b><b>2</b><b>3</b><b>4</b><b>5</b><b>6</b><b>7</b><b>8</b><b>9</b>
                                    </p>
                                </div>
                            </div>
                            <!-- 五星直选end -->
                            <!-- 五星通选start -->
                            <div class="jxsscxhlist" style="display: none;" id="5XTX">
                                <ul class="clearfix hide">
                                    <li m="y" v="万位" class="cur"><span>万位</span></li>
                                    <li m="y" v="千位" class="cur"><span>千位</span></li>
                                    <li m="y" v="百位" class="cur"><span>百位</span></li>
                                    <li m="y" v="十位" class="cur"><span>十位</span></li>
                                    <li m="y" v="个位" class="cur"><span>个位</span></li>
                                </ul>
                                <div class="jxsscxhBall mgTop03 jxsscline clearfix" v="5XTX" idx=0>
                                    <span>万位</span>
                                    <p><b>0</b><b>1</b><b>2</b><b>3</b><b>4</b><b>5</b><b>6</b><b>7</b><b>8</b><b>9</b>
                                    </p>
                                </div>
                                <div class="jxsscxhBall mgTop03 jxsscline clearfix" v="5XTX" idx=1>
                                    <span>千位</span>
                                    <p><b>0</b><b>1</b><b>2</b><b>3</b><b>4</b><b>5</b><b>6</b><b>7</b><b>8</b><b>9</b>
                                    </p>
                                </div>
                                <div class="jxsscxhBall mgTop03 jxsscline clearfix" v="5XTX" idx=2>
                                    <span>百位</span>
                                    <p><b>0</b><b>1</b><b>2</b><b>3</b><b>4</b><b>5</b><b>6</b><b>7</b><b>8</b><b>9</b>
                                    </p>
                                </div>
                                <div class="jxsscxhBall mgTop03 jxsscline clearfix" v="5XTX" idx=3>
                                    <span>十位</span>
                                    <p><b>0</b><b>1</b><b>2</b><b>3</b><b>4</b><b>5</b><b>6</b><b>7</b><b>8</b><b>9</b>
                                    </p>
                                </div>
                                <div class="jxsscxhBall mgTop03 clearfix" v="5XTX" idx=4>
                                    <span>个位</span>
                                    <p><b>0</b><b>1</b><b>2</b><b>3</b><b>4</b><b>5</b><b>6</b><b>7</b><b>8</b><b>9</b>
                                    </p>
                                </div>
                            </div>
                            <!-- 五星直通选end -->
                            <!-- 二星组选start -->
                            <div class="jxsscxhBall jxsscxhBall2 clearfix" style="display: none;" id="2XZXFS" v="2XZXFS">
                                <b>0</b><b>1</b><b>2</b><b>3</b><b>4</b><b>5</b><b>6</b><b>7</b><b>8</b><b>9</b></div>
                            <!-- 二星组选end -->
                            <!--组选三start-->
                            <div class="jxsscxhBall jxsscxhBall3 clearfix" style="display: none;" id="ZX3FS" v="ZX3FS">
                                <b>0</b><b>1</b><b>2</b><b>3</b><b>4</b><b>5</b><b>6</b><b>7</b><b>8</b><b>9</b></div>
                            <!--组选三end-->
                            <!--组选六start-->
                            <div class="jxsscxhBall jxsscxhBall4 clearfix" style="display: none;" id="ZX6" v="ZX6">
                                <b>0</b><b>1</b><b>2</b><b>3</b><b>4</b><b>5</b><b>6</b><b>7</b><b>8</b><b>9</b></div>
                            <!--组选六end-->
                            <!--二星合值start-->
                            <div class="jxsscxhBall clearfix" style="display: none;" id="2XHZ" v="2XHZ">
                                <b>0</b><b>1</b><b>2</b><b>3</b><b>4</b><b>5</b><b>6</b><b>7</b><b>8</b><b>9</b>
                                <b>10</b><b>11</b><b>12</b><b>13</b><b>14</b><b>15</b><b>16</b><b>17</b><b>18</b>
                            </div>
                            <!--二星合值end-->
                        </article>
                    </div>
                </section>
                <footer class="buyFooter">
                    <div class="fixed buyFloat">
                        <em class="deleted"></em>
                        <span id="zs_">共<cite class="yellow">0</cite>注<cite class="yellow">0</cite>元</span>
                        <a href="javascript:;" class="ture" id="isOk_">确 认</a>
                    </div>
                </footer>
            </article>
        </section>
        <script type="text/javascript">
            var gameCode = "CQSSC",gameName = "时时彩";
        </script>
        <script src="/scripts/bet.js" type="text/javascript"></script>
        <script src="/scripts/utils.js" type="text/javascript"></script>
    </div>
</div>
<div class="hide">
    {{----}}
</div>
</body>
</html>
